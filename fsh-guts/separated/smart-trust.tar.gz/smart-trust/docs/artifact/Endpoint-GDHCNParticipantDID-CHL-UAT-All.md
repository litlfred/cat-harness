---
title: "GDHCNParticipantDID-CHL-UAT-All — WHO SMART Trust artefact"
description: "Endpoint/GDHCNParticipantDID-CHL-UAT-All in the WHO SMART Trust IG, with its canonical URL, published representations and DAK API sidecars."
nav_exclude: true
ig_footer: true
ig_root: "../"
ig_prev: "Endpoint-GDHCNParticipantDID-CHL-DEV-SCA.html"
ig_next: "Endpoint-GDHCNParticipantDID-CHL-UAT-DSC.html"
---
<link rel="stylesheet" href="../assets/ig-pages.css">
<link rel="stylesheet" href="../assets/ig-chrome.css">

<div class="st-ig">
  <div class="st-ig-bar"><a href="http://smart.who.int/trust">smart.who.int.trust</a></div>
  <div id="ig-status" class="ig-status-draft">
    <p><span class="st-ig-title">WHO SMART Trust</span><br/><span>1.8.0 — draft</span></p>
  </div>
  <p id="publish-box">This page mirrors a published WHO Implementation Guide. The authoritative version is at <a href="http://smart.who.int/trust">http://smart.who.int/trust</a>.</p>
</div>

[← all 678 artefacts](../artifacts.html)

## GDHCNParticipantDID-CHL-UAT-All

`Endpoint/GDHCNParticipantDID-CHL-UAT-All`

Chile Trustlist (DID v2) - UAT - All keys did:web:tng-cdn.who.int:v2:trustlist:-:CHL resolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/CHL/did.json

<div class="st-grid"><div class="st-stat"><b>Endpoint</b><span>resource type</span></div><div class="st-stat"><b>—</b><span>version</span></div><div class="st-stat"><b>Other</b><span>category</span></div></div>

## Identity and bytes are different questions

| | |
|---|---|
| Canonical URL | *none — examples and instances have no canonical URL* |
| Published | <a href="https://litlfred.github.io/smart-trust/Endpoint-GDHCNParticipantDID-CHL-UAT-All.json">json</a> · <a href="https://litlfred.github.io/smart-trust/Endpoint-GDHCNParticipantDID-CHL-UAT-All.xml">xml</a> · <a href="https://litlfred.github.io/smart-trust/Endpoint-GDHCNParticipantDID-CHL-UAT-All.ttl">ttl</a> · <a href="https://litlfred.github.io/smart-trust/Endpoint-GDHCNParticipantDID-CHL-UAT-All.html">html</a> |
| Materialization | <span class="st-tag st-ref">referenced</span> — upstream, not held here |

## DAK API

No DAK API sidecar is published for this artefact. That is a fact about the IG,
not a gap in this index — sidecars are published per artefact, and
19 of 678 carry one.
