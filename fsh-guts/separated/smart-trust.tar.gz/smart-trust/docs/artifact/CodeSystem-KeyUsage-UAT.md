---
title: "WHO GDHCN Key Usage CodeSystem - UAT — WHO SMART Trust artefact"
description: "CodeSystem/KeyUsage-UAT in the WHO SMART Trust IG, with its canonical URL, published representations and DAK API sidecars."
nav_exclude: true
ig_footer: true
ig_root: "../"
ig_prev: "CodeSystem-KeyUsage-DEV.html"
ig_next: "CodeSystem-PayloadTypes.html"
---
<link rel="stylesheet" href="../assets/ig-pages.css">
<link rel="stylesheet" href="../assets/ig-chrome.css">

<div class="st-ig">
  <div class="st-ig-bar"><a href="http://smart.who.int/trust">smart.who.int.trust</a></div>
  <div id="ig-status" class="ig-status-draft">
    <p><span class="st-ig-title">WHO SMART Trust</span><br/><span>1.8.0 — draft</span></p>
  </div>
  <p id="publish-box">This page mirrors a published WHO Implementation Guide. The authoritative version is at <a href="http://smart.who.int/trust">http://smart.who.int/trust</a>.</p>
</div>

[← all 678 artefacts](../artifacts.html)

## WHO GDHCN Key Usage CodeSystem - UAT

`CodeSystem/KeyUsage-UAT`

CodeSystem for GDHCN Key Usage that has usage codes for verification keys published to the Trust Network as defined by the certificate governance for User Acceptance Testing environment

<div class="st-grid"><div class="st-stat"><b>CodeSystem</b><span>resource type</span></div><div class="st-stat"><b>1.8.0</b><span>version</span></div><div class="st-stat"><b>Terminology: Code Systems</b><span>category</span></div></div>

## Identity and bytes are different questions

| | |
|---|---|
| Canonical URL | `http://smart.who.int/trust/CodeSystem/KeyUsage-UAT` |
| Published | <a href="https://litlfred.github.io/smart-trust/CodeSystem-KeyUsage-UAT.json">json</a> · <a href="https://litlfred.github.io/smart-trust/CodeSystem-KeyUsage-UAT.xml">xml</a> · <a href="https://litlfred.github.io/smart-trust/CodeSystem-KeyUsage-UAT.ttl">ttl</a> · <a href="https://litlfred.github.io/smart-trust/CodeSystem-KeyUsage-UAT.html">html</a> |
| Materialization | <span class="st-tag st-ref">referenced</span> — upstream, not held here |

## DAK API

No DAK API sidecar is published for this artefact. That is a fact about the IG,
not a gap in this index — sidecars are published per artefact, and
19 of 678 carry one.
