---
title: "Holder — WHO SMART Trust artefact"
description: "ActorDefinition/Holder in the WHO SMART Trust IG, with its canonical URL, published representations and DAK API sidecars."
nav_exclude: true
ig_footer: true
ig_root: "../"
ig_prev: "../"
ig_next: "ActorDefinition-Issuer.html"
---
<link rel="stylesheet" href="../assets/ig-pages.css">
<link rel="stylesheet" href="../assets/ig-chrome.css">

<div class="st-ig">
  <div class="st-ig-bar"><a href="http://smart.who.int/trust">smart.who.int.trust</a></div>
  <div id="ig-status" class="ig-status-draft">
    <p><span class="st-ig-title">WHO SMART Trust</span><br/><span>1.8.0 — draft</span></p>
  </div>
  <p id="publish-box">This page mirrors a published WHO Implementation Guide. The authoritative version is at <a href="http://smart.who.int/trust">http://smart.who.int/trust</a>.</p>
</div>

[← all 678 artefacts](../artifacts.html)

## Holder

`ActorDefinition/Holder`

A Holder is an individual that has Verifiable Digtial Health Certificate in their possesion, received from an Issuer. The Holder may choose to share the Verifiable Digital Health Certificate with a Receiver.

<div class="st-grid"><div class="st-stat"><b>ActorDefinition</b><span>resource type</span></div><div class="st-stat"><b>1.8.0</b><span>version</span></div><div class="st-stat"><b>Requirements: Actor Definitions</b><span>category</span></div></div>

## Identity and bytes are different questions

| | |
|---|---|
| Canonical URL | `http://smart.who.int/trust/ActorDefinition/Holder` |
| Published | <a href="https://litlfred.github.io/smart-trust/ActorDefinition-Holder.json">json</a> · <a href="https://litlfred.github.io/smart-trust/ActorDefinition-Holder.xml">xml</a> · <a href="https://litlfred.github.io/smart-trust/ActorDefinition-Holder.ttl">ttl</a> · <a href="https://litlfred.github.io/smart-trust/ActorDefinition-Holder.html">html</a> |
| Materialization | <span class="st-tag st-ref">referenced</span> — upstream, not held here |

## DAK API

No DAK API sidecar is published for this artefact. That is a fact about the IG,
not a gap in this index — sidecars are published per artefact, and
19 of 678 carry one.
