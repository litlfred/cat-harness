---
doc_id: 9789241548960-eng
doc_title: "Handbook forGuideline Development 2nd edition"
section_id: sec-129-step-7-finalize-the-key-questions-and-the-import
section_title: "Step 7: finalize the key questions and the important and critical outcomes"
section_number: null
pages: 103-103
source_pdf: 9789241548960_eng.pdf
source_sha256: bfcd856e3ad7ab20
toc_source: outline
---
outcomes
The steering group should list the high-priority key questions and the outcomes which the GDG will use to formulate recommendations.
