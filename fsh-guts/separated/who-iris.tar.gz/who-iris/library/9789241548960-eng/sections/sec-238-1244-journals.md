---
doc_id: 9789241548960-eng
doc_title: "Handbook forGuideline Development 2nd edition"
section_id: sec-238-1244-journals
section_title: "Journals"
section_number: 12.4.4
pages: 174-174
source_pdf: 9789241548960_eng.pdf
source_sha256: bfcd856e3ad7ab20
toc_source: outline
---
The systematic reviews commissioned for the guideline may be submitted for 
publication in the Bulletin of the World Health Organization or other journals. Cochrane reviews are published in the Cochrane Library. To increase 
awareness of the guideline, the guideline development process and/or recommendations may also be published in peer-reviewed journals, in compliance 
with WHO’s open access and copyright policies. All external publications 
with WHO authors require internal clearance.
