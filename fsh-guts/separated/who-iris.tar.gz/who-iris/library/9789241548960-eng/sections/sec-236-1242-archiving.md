---
doc_id: 9789241548960-eng
doc_title: "Handbook forGuideline Development 2nd edition"
section_id: sec-236-1242-archiving
section_title: "Archiving"
section_number: 12.4.2
pages: 174-174
source_pdf: 9789241548960_eng.pdf
source_sha256: bfcd856e3ad7ab20
toc_source: outline
---
At the time of publication, the department should ensure that archiving 
requirements are met. In headquarters, departments should send the final 
electronic file of their guideline to the WHO Library for inclusion in the Institutional Repository for Information Sharing (IRIS) (4). In regional offices, 
departments should send the final electronic file of their information products to their regional office library. If printed copies are produced, one should 
also be sent for inclusion in the print collection of the respective library.
