---
doc_id: who-pub-tps-931
doc_title: "WHO Editorial Style Manual"
section_id: page-055
section_title: "Page 55"
pages: 55-55
pdf_page: 55
source_pdf: WHO_PUB_TPS_93.1.pdf
source_sha256: ecc88eee99756755
text_source: ocr
granularity: page
---
WHO Editorial Style Manual

Term Symbol
variable in a population XY)...
particular or observed value KI ae
population or lot size N
sample size n
range of a sample w,R
arithmetic mean of a population X
arithmetic mean of a sample RK
variance of a random variable or of a population com

variance of a sample z
standard deviation of a random variable or of a population o
standard deviation of a sample 5

coefficient of correlation between two random variables or in a population p
coefficient of correlation in a sample t

number of degrees of freedom v

standard normal variable U
particular value of the standard normal variable WU, %
chi-squared distribution 7
t-distribution (Student) t

F-distribution F
level of significance of a test, type I risk 7
type II risk B
probability of an event E Pr

Several abbreviations are in common use in running text, for example:

Cl confidence interval
df degrees of freedom
SD standard deviation
SE standard error.

In statistical analyses, the mean should be supported by statistics such
as the number of observations, the standard deviation (a measure of the
variability of a sét of data) or the standard error (a measure of the
precision of an estimate, commonly the mean). Avoid presenting
variability in the form SE = +1.3, which wrongly implies that SE can be
negative. Probability values are usually quoted in the form “P < 0.001”.

Further reading ; ;
Altman DG etal. Statistical guidelines for contributors to medical journals. British
medical journal, 1983, 286:1489-1493.

Gardner MJ, Altman DG. Confidence intervals rather than P values: estimation
rather than hypothesis testing. British medical journal, 1986, 292:746-750.

Swinscow TDV. Statistics at square one, 9th ed. (revised). London, BMJ Publishing
Group, 1996.

50
