---
doc_id: who-pub-tps-931
doc_title: "WHO Editorial Style Manual"
section_id: page-095
section_title: "Page 95"
pages: 95-95
pdf_page: 95
source_pdf: WHO_PUB_TPS_93.1.pdf
source_sha256: ecc88eee99756755
text_source: ocr
granularity: page
---
WHO Editorial Style Manual

L

label, labelled, labelling

labour, laborious

labour-intensive

lacrimal; lacrimate

laissez-faire :

laissez-passer (invariable sing. & pl.)

large-scale (adj.; but on a large scale)

larva (pl. larvae)

last-mentioned

Latin American (n. & adj.)

lay out (vb)

layout (n.)

learned (erudite)

least developed countries

leptospirosis .

leukaemia

leukocyte

leukopenia

liaison

licence (n.)

license (vb)

life cycle

life expectancy

lifelong

life span

lifestyle

life-support (adj.)

lifetime

lightening (the sky is)

lightning (the sky is full of)

liquefaction (not liquifaction):

liquefy (not liquify)

litre (symbol = 1, but prefer litre -
where ambiguity may arise)

live birth

liveborn (adj.)

livestock

loath (adj.)

loathe (vb)

logbook

logistic (not logistical)

long-distance (adj.; but at a long
distance)

long-term (adj.; but in the long
term)

loophole

louse-borne

low back pain

low-cost (adj.; but at low cost)

lump-sum reimbursement (but as a
lump sum)

lying-in hospital (but the mother
was lying in)

lymphadenoma

lymphadenopathy

lymph glands

lymph nodes

macroeconomics

man-hours, man-months, etc.
(prefer work-hours, work-
months, etc.)

man-made

manoeuvre, manoeuvrable (not
maneuver, maneuverable)

marijuana (not marihuana)

matrix (pl. matrices)

may be (vb) °

maybe (perhaps)

meantime

media (plural word; sing. medium)

media (pl. mediae) of blood vessel

Mediterranean

melting-point

Member countries

Member States (of WHO etc.)

members of the Executive Board
(persons designated by Member
States)

memorandum (pl. memoranda)

meningococcal

meningococcus (not Meningococcus)

meningoencephalitis

meter (measuring device)

metre (unit of length; symbol = m)

microbiological, microbiology

microcomputer, microprocessor

microculture

microeconomics

microfiche (pl. microfiches)

micrometer (measuring device)

micrometre (unit of length)

microorganism

midday

90
