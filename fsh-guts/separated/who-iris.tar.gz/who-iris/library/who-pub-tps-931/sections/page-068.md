---
doc_id: who-pub-tps-931
doc_title: "WHO Editorial Style Manual"
section_id: page-068
section_title: "Page 68"
pages: 68-68
pdf_page: 68
source_pdf: WHO_PUB_TPS_93.1.pdf
source_sha256: ecc88eee99756755
text_source: ocr
granularity: page
---
15. Non-discriminatory language

Of the examples of discrimination that are most likely to be encoun-
tered in manuscripts, the most common involve discrimination on the
grounds of sex. For this reason, the guidelines presented here concen-
trate largely on means of avoiding overt or implied sex discrimination.
However, examples of racial or cultural discrimination may also be
found, and many of the principles that apply to the elimination of
sex discrimination can also be applied to the eradication of other types

of bias.

Modifying the way people speak and write is not easy, and there is —
and will continue to be — considerable resistance to change. Unless the
use of non-discriminatory language becomes standard practice, how-
ever, the achievement of sexual, racial and cultural equality will be

hindered.

The importance of non-discriminatory language

Women’s role in society can be unconsciously diminished or trivialized
bya failure to mention them specifically in writing—thus implying that
they are less important than men.

By excluding women, sexist language can cause offence. It is the
mistaken belief of many authors that their use of terms such as “man”,
“he” and “him” will be assumed by their readers to include women.
Most readers make no such assumptions. Moreover, the use of exclu-
sively masculine nouns and pronouns to denote both men and women.
can become hopelessly ambiguous and lead to confusion, as in the
following example:

“As for man, he is no different from the rest. His back aches, he

ruptures easily, his women have difficulties in childbirth.”

Further examples demonstrate how sexist writing reinforces many
common but inaccurate concepts of the roles of men and women in
society:

“Research scientists often neglect their wives and children.”

“It is a great secret of doctors, known only by their wives ... that most
things get better by themselves.”

63
