---
doc_id: who-pub-tps-931
doc_title: "WHO Editorial Style Manual"
section_id: page-042
section_title: "Page 42"
pages: 42-42
pdf_page: 42
source_pdf: WHO_PUB_TPS_93.1.pdf
source_sha256: ecc88eee99756755
text_source: ocr
granularity: page
---
1]. Abbreviations and symbols

The purpose of abbreviations is to save space in figures and tables or
when the same word or phrase occurs many times in an article. All
abbreviations should be defined the first time they are used, unless
likely to be familiar to readers. A few abbreviations (e.g., i.e., viz., etc.)
are so widely used that the complete words are almost never given.
However, editors should use their discretion when employing abbre-
viations, since overuse of less familiar abbreviations can be ahindrance
to readers. Care should also be taken to avoid the use of abbreviations
that may be confusing.

Symbols, which can be alphabetic, alphanumeric or graphic in form,
are used to represent quantities, units, substances (e.g. amino acids,
immunoglobulins), chromosomes, mathematical operations, etc. They
are often (but not necessarily) abbreviations. For further information
on specific symbols, see “Statistics”, in section 13, and “Scientific
terminology”, section 14.

Structure of abbreviations and symbols

Abbreviations and symbols may be formed in any one of the following
ways:

1. By omitting the end of a word, which should be replaced by a full
stop: Jan., Co.

2. By suppressing the middle of a word: Dr, Mr (a full stop is not
usually required).

3. By combining the initial letters of the main words, or compo-
nents of words, in expressions such as titles of organizations,
compound names of chemical substances, or certain medical
terms: WHO (World Health Organization), DDT (dichloro-
diphenyltrichloroethane), CNS (central nervous system). In
abbreviations of this kind, capitals should be used without full
stops.

4. By using one or more letters of the word in question, or even
letters or signs that do not figure in it, to form a symbol (asin units
of measurement and chemical elements): J (joule), Pb (lead),
ig (microgram).

Where an abbreviation requiring a full stop falls at the end of a
sentence, a second full stop need not be added.

37
