---
doc_id: who-pub-tps-931
doc_title: "WHO Editorial Style Manual"
section_id: page-094
section_title: "Page 94"
pages: 94-94
pdf_page: 94
source_pdf: WHO_PUB_TPS_93.1.pdf
source_sha256: ecc88eee99756755
text_source: ocr
granularity: page
---
!

i.e. (no comma)

illegible

ill effect

ill-health

immunochemistry

immunodiagnosis

immunological (not immunologic)

immunomodulation

immunosuppressive

impracticable (impossible in
practice)

impractical (not practical)

inasmuch as (2 words)

indexes (of texts etc.)

indices (mathematical, scientific)

ineligible

infarct, infarction (of myocardium)

inflection (not inflexion)

infraction. (of rules)

infrared :

infrastructure (does not normally
need a plural)

innocuous

inoculate, inoculation

inpatient

input

inquire, inquiry (of investigation,
especially of official nature)

insanitary (not unsanitary)

in-service training

insignia (plural word)

m™ situ

in so far as (4 words)

install, installed, instalment

instil, instilled, instillation

insure (against risk; compare ensure)

interact, interaction

interagency

inter alia

inter-American

Inter-American Development Bank

intercostal

intercountry

interdepartmental

intergovernmental

International Labour Office
(Secretariat)

Annex 1 — Spelling of words that commonly cause difficulty

International Labour Organisation
(not ...Organization)

interracial

interregional

interrelated, interrelationship

intersectoral (not intersectorial)

intervertebral

intifada

into (1 word)

intra-abdominal

intracutaneous

intradermal

intramural

intramuscular

intraocular

intraregional

intrauterine

intravascular

intravenous

in vitro

in vivo

iodinated

iodized

iron deficiency anaemia

irradiated

ischaemia, ischaemic

isolatable (not isolable)

J

joule (J)

Jt (= Junior)

judgement (bur Judgments of
Administrative Tribunal of ILO)

juxta-articular

K

Kellogg Foundation
kerosene

khat

kilogram (kg)
kilojoule (k})
kilometre (km)
kilowatt (kW)
knee-jerks
know-how
kwashiorkor

89
