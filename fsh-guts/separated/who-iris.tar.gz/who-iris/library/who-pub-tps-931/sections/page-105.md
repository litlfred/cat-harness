---
doc_id: who-pub-tps-931
doc_title: "WHO Editorial Style Manual"
section_id: page-105
section_title: "Page 105"
pages: 105-105
pdf_page: 105
source_pdf: WHO_PUB_TPS_93.1.pdf
source_sha256: ecc88eee99756755
text_source: ocr
granularity: page
---
WHO Editorial Style Manual

Short name Full name Adjective/People Capital city
Benin the Republic of Benin Beninese Porto-Novo
Bhutan the Kingdom of Bhutan Bhutanese Thimphu
Bolivia the Republic of Bolivia Bolivian Sucre!
Bosnia and Bosnia and (of) Bosnia Sarajevo
Herzegovina Herzegovina and Herzegovina
Botswana the Republic of Botswana (of) Botswana Gaborone
Brazil the Federative Republic Brazilian Brasilia
of Brazil
Brunei Darussalam Brunei Darussalam (of) Brunei Bandar Seri
Darussalam Begawan
Bulgaria the Republic of Bulgaria Bulgarian Sofia
Burkina Faso Burkina Faso , (of) Burkina Faso = Ouagadougou
Burma: see Myanmar
Burundi the Republic of Burundi (of) Burundi, Bujumbura
Burundian
Cambodia the Kingdom of Cambodia | Cambodian Phnom Penh
Cameroon the Republic of Cameroon — Cameroonian Yaoundé
Canada - Canada Canadian Ottawa
Cape Verde the Republic of Cape Verde Cape Verdean Praia
Central African the Central African Republic of the Central Bangui
Republic (the) African Republic,
Central African
Chad the Republic of Chad Chadian N’Djamena
Chile the Republic of Chile Chilean Santiago
China the People’s Republic Chinese Beijing
of China ‘
Colombia the Republic of Colombia Colombian Bogota
Comoros (the) the Islamic Federal Republic Comorian Moroni
of the Comoros
Congo (the) the Republic of the Congo —_ Congolese Brazzaville
Cook Islands the Cook Islands of the Cook Avarua
Islands
Costa Rica : the Republic of Costa Rica Costa Rican San José
Céte d'Ivoire the Republic of Céte d'Ivoire Ivorian Yamoussoukro”

1 Seat of Government: La Paz,
2 Seat of Government: Abidjan.

100
