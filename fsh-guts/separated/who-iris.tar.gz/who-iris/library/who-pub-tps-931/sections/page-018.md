---
doc_id: who-pub-tps-931
doc_title: "WHO Editorial Style Manual"
section_id: page-018
section_title: "Page 18"
pages: 18-18
pdf_page: 18
source_pdf: WHO_PUB_TPS_93.1.pdf
source_sha256: ecc88eee99756755
text_source: ocr
granularity: page
---
1. To mark the antithesis between two statements more sharply
than a semicolon.

2. To introduce a list or series — never followed by a dash.

3. To indicate that the second statement is an explanation or
amplification of the first.

Parenthesis

A parenthesis can be marked off by commas, dashes or brackets,
depending upon the closeness of its relationship to the sentence.

Parentheses should be used sparingly since they tend to break up
sentence structure and can too often be used to save the trouble of
organizing one’s thoughts.

Spaced em or en rules are used as parenthetical dashes. If unspaced in
the typescript, they should have a vertical line on either side, but a
space sign is unnecessary.

Dashes
Hyphen

It is not possible to be didactic about hyphens without being mislead-
ing, but they should be avoided whenever possible and introduced only
to avoid ambiguity.

The practice of separating two or more prefixes to the same word,
leaving a hyphen in mid-air, should be avoided if possible, e.g.

... hypertension or hypotension ... not ... hyper- or hypotension ...

Use of the hyphen with appropriate examples is described in greater
detail in section 2.

En rule

An en rule is longer than a hyphen and is most commonly used to
convey a distinction in sense when the first part of the compound does
not modify the meaning of the second part — unlike the hyphen. The
en rule in these circumstances can usually be thought of as standing for
“and” or “to”, and is usually unspaced, e.g.

case-control study
benefit-risk ratio

oil-water interface
gas-liquid chromatography.

Punctuation

13
