---
doc_id: who-pub-tps-931
doc_title: "WHO Editorial Style Manual"
section_id: page-010
section_title: "Page 10"
pages: 10-10
pdf_page: 10
source_pdf: WHO_PUB_TPS_93.1.pdf
source_sha256: ecc88eee99756755
text_source: ocr
granularity: page
---
Hyphenation

Hyphensare used to connect words that are more closely linked to each
other than to the surrounding syntax. Unfortunately there are no hard
and fast rules about their use. Certain conventions exist, but if there is
a choice it is better to introduce hyphens only to avoid ambiguity.
There is an overall tendency to use hyphens less than in the past and
a few general rules are applicable, as follows.

Hyphen after a prefix

A hyphen should be used after a prefix in order to prevent the word
being mistaken for another one, e.g. co-op, coop (but cooperate needs
no hyphen); re-cover, recover; un-ionized, unionized.

Prefixes such as anti- and semi- can often be used without a hyphen,
e.g. antihypertensive, antidysrhythmic, semiconductor, semicircular.
However, a hyphen is required to avoid doubling a vowel or a
consonant, e.g. anti-inflammatory, anti-infective, semi-invalid.

A hyphen is also required when the prefix is to a word beginning
with a capital letter, e.g. anti-Darwinian, sub-Saharan (but note
Pan American Health Organization).

Hyphens with compound nouns and adjectives

Some compound words remain hyphenated irrespective of their gram-
matical use, e.g. well-being, side-effect, extra-articular, forty-two,
Vice-President, Director-General. Others are hyphenated according
to whether they are used as nouns or adjectives, e.g. first-class (adj.) but
first class (n.), low-cost (adj.) but low cost (n.), or whether they are
used attributively or as predicates, e.g. up-to-date statistics but the
statistics are up to date.

It is usually unnecessary to insert a hyphen after an adverb, e.g.
carefully developed plan, well known fact, buta hyphen is appropriate
when an adverb might be mistaken for an adjective (compare little-
used car and little used car).

Spelling
