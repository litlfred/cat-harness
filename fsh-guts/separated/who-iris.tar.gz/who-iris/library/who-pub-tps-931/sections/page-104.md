---
doc_id: who-pub-tps-931
doc_title: "WHO Editorial Style Manual"
section_id: page-104
section_title: "Page 104"
pages: 104-104
pdf_page: 104
source_pdf: WHO_PUB_TPS_93.1.pdf
source_sha256: ecc88eee99756755
text_source: ocr
granularity: page
---
Annex 2

Member States of the United Nations, members
of specialized agencies or parties to the Statute
of the International Court of Justice!

Short name Full name Adjective/People Capital city
Afghanistan the Islamic State of Afghan Kabul

Afghanistan :
Albania the Republic of Albania Albanian Tirana
Algeria the People’s Democratic Algerian Algiers

: Republic of Algeria
Andorra the Principality of Andorra Andorran Andorra-
La-Vella

Angola the Republic of Angola Angolan Luanda
Antigua and Antigua and of Antigua St John’s
Barbuda Barbuda and Barbuda
Argentina the Argentine Republic Argentine Buenos Aires
Armenia the Republic of Armenia Armenian Yerevan
Australia Australia Australian Canberra
Austria the Republic of Austria Austrian Vienna
Azerbaijan the Azerbaijani Republic Azerbaijani Baku
Bahamas (the) the Commonwealth Bahamian Nassau

of the Bahamas
Bahrain the State of Bahrain Bahraini Manama
Bangladesh the People’s Republic (of) Bangladesh, Dhaka

of Bangladesh a Bangladeshi
Barbados Barbados Barbadian, Bridgetown
Belarus the Republic of Belarus Belarusian Minsk
Belgium the Kingdom of Belgium Belgian Brussels
Belize Belize . Belizean. Belmopan

1 This annex is valid as at 22 January 1998, but CTT or LEG should be consulted for information
on more recent changes and additions. The listing of capital cities is provided for general
information purposes; however, it cannot be relied upon as authoritative. The United Nations,
which is the source of information for this annex, does not maintain an official list of capital cities.

99
