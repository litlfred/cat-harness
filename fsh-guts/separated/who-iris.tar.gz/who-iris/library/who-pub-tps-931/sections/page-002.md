---
doc_id: who-pub-tps-931
doc_title: "WHO Editorial Style Manual"
section_id: page-002
section_title: "Page 2"
pages: 2-2
pdf_page: 2
source_pdf: WHO_PUB_TPS_93.1.pdf
source_sha256: ecc88eee99756755
text_source: ocr
granularity: page
---
Contents

1. Introduction

2. Spelling

Medical and scientific terminology
Country and place names
Syllabification

Hyphenation

Capitalization

Words ending in -ize, -ise and -yse
Alphabetical arrangement

3. Punctuation

Full point (period)
Comma
Semicolon

Colon

Parenthesis
Dashes

Brackets

Question mark
Further reading

4, Italics

Titles of books and journals

Foreign words and expressions
Variables in mathematical expressions
Scientific terms

Words requiring special emphasis

5. Footnotes
Identification

Editor’s notes
Paragraphing and style

6. Quotations

7, Transliteration
Arabic
Russian

Chinese

8. Copyright and disclaimers
Reproducing previously published material

SrwoeurR Aww ~

W
12
12
12
13
13
4
15
15

17
V7
V7
18
18
18

19
i
20
20

21

23
23
23
24

25
26

iff
