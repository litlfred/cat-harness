---
doc_id: who-pub-tps-931
doc_title: "WHO Editorial Style Manual"
section_id: page-037
section_title: "Page 37"
pages: 37-37
pdf_page: 37
source_pdf: WHO_PUB_TPS_93.1.pdf
source_sha256: ecc88eee99756755
text_source: ocr
granularity: page
---
WHO Editorial Style Manual

Tables

Tables should be kept as simple as possible, with brief titles and column
headings. Restrict the use of rules, unless the table is particularly
complex. Vertical lines should generally be avoided, but straddle rules
over column headings are useful for clarifying hierarchical arrange-
ments. When units of measurement or multiplication factors appear in
column headings, ensure that there is no possibility of misinterpreta-
tion; “Concentration (mg/litre)” is clear, but “No. of cases detected
(x 10°)” is ambiguous. A column should not contain any blanks; use
dashes or abbreviations where data are missing (for example NA, ND,
for “not applicable”, “not determined”).

Additional information should be given in the form of footnotes,
generally identified with superscript letters placed in the appropriate
order in the table from left to right and top to bottom. The same mark
may be used on two or more elements if the corresponding note applies
to them, for example:

Data based on a teratogenicity study in which ochratoxin A was
administered on day 9 of gestation.

Fora table consisting only of words or letters, superscript numbers may
be used as reference marks to identify footnotes, and for a table that
includes mathematical or chemical equations a series of symbols may
be used, because of the risk of mistaking letters or numbers for
exponents:

* (asterisk), | (dagger), $ (double dagger), § (section mark).

When more symbols are needed, these may be doubled and tripled in
the same sequence. Asterisks are conventionally also used to indicate
levels of statistical significance.

The footnotes should be printed immediately below the table. They
are of four general kinds and should appear in this order:

1. Explanations of abbreviations and notes on levels of statistical
significance. A single asterisk is used for the lowest level of
significance, two for the next level, and so on, with the specific
level given in the following form: :

*P < 0.05, **P < 0.01, ***P < 0.001.
2. Source and general notes. If data for a table are not the author’s

own butare taken from another source, the author should include
a source note, introduced by the word “Source(s):”, for example:

32
