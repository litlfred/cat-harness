---
doc_id: who-pub-tps-931
doc_title: "WHO Editorial Style Manual"
section_id: page-048
section_title: "Page 48"
pages: 48-48
pdf_page: 48
source_pdf: WHO_PUB_TPS_93.1.pdf
source_sha256: ecc88eee99756755
text_source: ocr
granularity: page
---
FSH
GABA
GH
GnRH
HAT
HBV
HCG
HIV
HLA

HPLC
HTLV
MHC
IDT
IFAT
IFT

Ig

IR
LAT
1D,
LFT
tH
MAb
mRNA
NSAID
PAGE
PCV
PMSG
RAST
RFLP
RISA
RIST
RNA*
tRNA
SDS
SDS-PAGE
Sp-, Spp.*
TCD,,
TLC
tRNA
UV

follicle-stimulating hormone
gamma-aminobutyric acid

growth hormone

gonadotropin-releasing hormone
haemagglutination antibody test

hepatitis B vaccine (virus)

human chorionic gonadotropin

human immunodeficiency virus
histocompatibility leukocyte (locus) antigen; human
leukocyte (lymphocyte) antigen
high-pressure (performance) liquid chromatography
human T-cell lymphotropic virus

major histocompatibility complex
immunodiffusion test

indirect fluorescent antibody test
immunofluorescence test
immunoglobulin (IgA*, IgD*, IgE*, IgG*, IgM*)
infrared

latex agglutination test

median lethal dose

latex flocculation test

luteinizing hormone

monoclonal antibody

messenger ribonucleic acid

non-steroidal anti-inflammatory drug
polyacrylamide gel electrophoresis
packed cell volume

pregnant mare serum gonadotropin
radioallergosorbent test

restriction fragment length polymorphism
radioimmunosorbent assay
radioimmunosorbent test

ribonucleic acid

ribosomal ribonucleic acid

sodium dodecyl sulfate

Abbreviations and symbols

sodium dodecyl sulfate—polyacrylamide gel electrophoresis

species

median tissue culture infective dose
thin-layer chromatography

transfer ribonucleic acid

ultraviolet

43
