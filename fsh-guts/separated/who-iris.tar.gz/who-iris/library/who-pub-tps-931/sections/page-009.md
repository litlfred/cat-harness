---
doc_id: who-pub-tps-931
doc_title: "WHO Editorial Style Manual"
section_id: page-009
section_title: "Page 9"
pages: 9-9
pdf_page: 9
source_pdf: WHO_PUB_TPS_93.1.pdf
source_sha256: ecc88eee99756755
text_source: ocr
granularity: page
---
WHO Editorial Style Manual

Eponymous names give no information about the nature of the disease
and different names may be used in different countries. They should be
avoided whenever possible. The Saxon genitive (’s) is not necessary
when using an eponymous name; e.g. Crohn disease, not Crohn’s
disease, and Down syndrome, not Down’s syndrome.

For general reference, Butterworths medical dictionary, 2nd ed. (Critchley
M, ed. London, Butterworths, 1978) and Dorland’s illustrated medical
dictionary, 28th ed. (Philadelphia, Saunders, 1994) can be recom-
mended for British and American spelling, respectively.

Progress in medical terminology (Manuila A, ed. Basel, Karger, 1981)
describes the evolution of medical terminology and gives a detailed
account of the development of the IND.

For scientific spelling and terminology see section 14.

Country and place names

Webster’s new geographical dictionary (Springfield, Merriam-Webster,
1984) can be used as 4 guide to the spelling of common geographical
entities. However, country names and their spelling, in particular, can
change at an alarming rate. The Computer-Assisted Translation and
Terminology subunit (CTT), which coordinates with the Office of the
Legal Counsel (LEG), can provide up-to-date information on the
names of United Nations and WHO Member States, including their
full, short and adjectival/attributive forms.

The official names of United Nations Member States and approved
and alternative names for various cities and countries are listed in
Annexes 2 and 3. For countries such as “The Gambia” and “The
Netherlands”, the definite article may be omitted in address lists and
enumerations.

Syllabification

The first edition of Collins dictionary of the English language (Hanks P,
ed. London, Collins, 1979) gives syllabification breaks and appropriate
hyphenation points for each entry. The position of syllabic breaks
where hyphenation is permissible is based upon phonetic rather than
etymological principles, e.g. cata-lyse, but ca-taly-sis; meta-bol-ic, but
met-abo-lism.
