---
doc_id: who-pub-tps-931
doc_title: "WHO Editorial Style Manual"
section_id: page-084
section_title: "Page 84"
pages: 84-84
pdf_page: 84
source_pdf: WHO_PUB_TPS_93.1.pdf
source_sha256: ecc88eee99756755
text_source: ocr
granularity: page
---
Useful reference books

Scientific, technical and medical terminology and usage

Armstrong Lowe D. A guide to international recommendations on names
and symbols for quantities and on units of measurement. Geneva, World
Health Organization, 1975 (Progress in standardization, No. 2).

Baron DN, ed. Units, symbols, and abbreviations: a guide for biological and
medical editors and authors, 4th ed. London, Royal Society of Medicine
Services, 1988.

Budavari S et al., eds. The Merck index, 12th ed. Whitehouse Station,
NJ, Merck, 1996.

Cahn RS, Dermer OC. Introduction to chemical nomenclature, Sth ed.
London, Butterworths, 1979.

Enzyme nomenclature, 1992: recommendations of the Nomenclature
Committee of the International Union of Biochemistry and Molecular
Biology on the nomenclature and classification of enzymes. San Diego,
Academic Press, 1992.

Guidelines for reporting and writing about people with disabilities, 3rd ed.
Lawrence, KS, Research and Training Center on Independent Living,
1990.

Heister R. Dictionary of abbreviations in medical sciences. Berlin. Springer
Verlag, 1989.

International code of zoological nomenclature adopted by the 20th Generel
Assembly of the International Union of Biological Sciences, 3rd ed.
London, International Trust for Zoological Nomenclature, 1985.

International Nomenclature of Diseases. Geneva, CIOMS or CIOMS:
WHO, 1979-1992.
Volume II, infectious diseases
Part 1, bacteriai diseases
Part 2, mycoses
Part 3, viral diseases
Part 4, parasitic diseases
Volume HI, diseases of the ‘ower respiratory tract
Volume IV, diseases of the digestive system
Volume V, cardiac and vascular diseases
Volume VI, metabolic, nutritional, and endocrine disorders
Volume VII, diseases of the kidney, the lower urinary tract,
and the male genizal system
Volume VIII, diseases of che female genital system

9
