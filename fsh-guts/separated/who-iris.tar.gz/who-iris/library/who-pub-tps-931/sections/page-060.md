---
doc_id: who-pub-tps-931
doc_title: "WHO Editorial Style Manual"
section_id: page-060
section_title: "Page 60"
pages: 60-60
pdf_page: 60
source_pdf: WHO_PUB_TPS_93.1.pdf
source_sha256: ecc88eee99756755
text_source: ocr
granularity: page
---
Scientific terminology

“Cy, acid” is used to denote an acid containing 20 carbon atoms and
“C-3” to denote the carbon atom numbered 3.

Oxidation numbers are indicated by roman numerals in parentheses
closed up against the name of the element concerned, for example:
manganese(IV)

Cr(LII).

Further reading
Budavari S et al., eds. The Merck index, 12th ed. Whitehouse Station, NJ, Merck,
1996.

Cahn RS, Dermer OC. Introduction to chemical nomenclature, 5th ed. London,
Butterworths, 1979.

TUPAC Commission on the Nomenclature of Inorganic Chemistry. Nomenclature
of inorganic chemistry, 3rd ed. Oxford, Blackwell Scientific, 1990.

IUPAC Commission on the Nomenclature of Organic Chemistry. Nomenclature of
organic chemistry: sections A, B,C, D, E, FandH, revised ed, Oxford, Pergamon, 1979.

Isotopic labelling

The symbol for the isotope introduced is placed in square brackets
directly attached to the part of the name to which it refers (e.g. sodium
('4C]formate); appropriate arabic numerals and prefixes are added as
necessary (e.g. L-[2-C]leucine). For simple molecules, chemical
formulae may be used (e.g. 4#CO,).

Square brackets should not be used when the isotopic symbol is
attached to a word that is not a chemical name (e.g. “!*C-labelled”).
Terms such as “'![-labelled albumin” should not be contracted to
[3!T]albumin since native albumin does not contain iodine.

In text, an isotope can be identified in the following form:
phosphorus-32 — iodine-131.

Prefixes

Various stereochemical prefixes are in use, including:
(R)- cis- D- (E)- (+)- (+)-
(S)- trans- L- (Z)- (-)- meso-.

The older prefixes dextro, abbreviated d and equivalent to (+), and
laevo, abbreviated | and equivalent to (—), should no longer be used.
Certain prefixes should be italicized (see also above):

o-,m-, p- (but these locants have generally been abandoned by
Chemical abstracts in favour of numerals)

55
