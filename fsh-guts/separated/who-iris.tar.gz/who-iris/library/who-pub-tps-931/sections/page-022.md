---
doc_id: who-pub-tps-931
doc_title: "WHO Editorial Style Manual"
section_id: page-022
section_title: "Page 22"
pages: 22-22
pdf_page: 22
source_pdf: WHO_PUB_TPS_93.1.pdf
source_sha256: ecc88eee99756755
text_source: ocr
granularity: page
---
4. Italics

Italic type in printed publications is indicated in typescript by under-
lining. Italics are used in WHO publications in the following ways:

for the titles of books, journals and documents;

for foreign words and expressions not in common use (including
Latin species and genus names);

for variables in mathematical expressions;

for certain letters, prefixes and terms in scientific use;
(sparingly) for words requiring special emphasis.

Titles of books and journals

See “Reference lists and bibliographies”, section 9.

Foreign words and expressions

Italicize foreign words and phrases not in common use. The list below
gives examples of current WHO practice in this regard; for words not
in this list, consult the latest edition of The concise Oxford dictionary, or
Hart's rules for compositors and readers at the University Press Oxford,
39th ed. (Oxford, Oxford University Press, 1983). The names of
institutions and organizations such as Médecins sans frontires should
generally be italicized in running text but not in address lists.

Italicize: pro tempore corrigendum lacuna
a priori raison d’étre créche laissez-passer
carte blanche sensu stricto curriculum per annum
chef-d’ oeuvre sine qua non vitae per capita
coup d’ état vis-a-vis de facto précis
en masse eg. prima facie
en route Print in roman: élite pro rata
fait accompli addendum erratum rapporteur
in situ ad hoc etal. résumé
In vitro alias etc. status quo
in vivo attaché et seq. verbatim
laissez-faire avant-garde ex officio versus
modus operandi blasé habeas corpus via
per se bona fide in camera vice versa
piéce de cliché incommuni-

résistance communiqué cado

7
