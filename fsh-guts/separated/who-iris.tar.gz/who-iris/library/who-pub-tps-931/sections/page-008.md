---
doc_id: who-pub-tps-931
doc_title: "WHO Editorial Style Manual"
section_id: page-008
section_title: "Page 8"
pages: 8-8
pdf_page: 8
source_pdf: WHO_PUB_TPS_93.1.pdf
source_sha256: ecc88eee99756755
text_source: ocr
granularity: page
---
2. Spelling

This section is a general guide to spelling used in WHO publications,
and also gives guidelines on hyphenation and capitalization. It is not
intended to be comprehensive, but to cover the main areas, such as
scientific and medical terminology, and names of places and organiza-
tions, where confusion and uncertainty may arise.

Within WHO, British rather than American spelling is normally used.
The general rule is to follow the first spelling listed in the latest edition
of The concise Oxford dictionary. If a variant spelling is listed separately,
the one to which you are referred should be used; e.g. “tire, US var. of
tyre”: use “tyre”.

There are, however, a number of exceptions:

© where adifferent spelling has become established usage in WHO;

© where there is anced to respect the recommendations of interna-
tional nomenclature-setting bodies;

© quoted material, where the original spelling must be reproduced
exactly; and

* book and article titles, where the original spelling must be
reproduced.

Annex 1 gives the preferred spellings of many of the commonly
encountered exceptions; it also includes The concise Oxford dictionary
spellings that should be followed for many words that often cause doubt
or difficulty, and gives some guidelines on usage and choice of words.

For transliteration from Arabic, Russian and Chinese see section 7.

Medical and scientific terminology

The spelling of disease names and other medical terms follows British
rather than American usage. Some frequently found exceptions are:

estrogen, estrus, etc. (but oesophagus and oedema)
etiology

fetal, fetus, etc.

leukocyte, leukopenia.

For disease names and their spelling, the International Nomenclature
of Diseases (IND) should be followed. This must not be confused with
the International Classification of Diseases (ICD), which is a statisti-
cal classification and not a nomenclature.
