---
doc_id: who-pub-tps-931
doc_title: "WHO Editorial Style Manual"
section_id: page-111
section_title: "Page 111"
pages: 111-111
pdf_page: 111
source_pdf: WHO_PUB_TPS_93.1.pdf
source_sha256: ecc88eee99756755
text_source: ocr
granularity: page
---
WHO Editorial Style Manual

Short name Full name Adjective/People Capital city
Somalia the Somali Democratic Somali Mogadishu
Republic
South Africa the Republic of South Africa South African Pretoria
Spain the Kingdom of Spain Spanish, a Spaniard §Madrid
Sri Lanka the Democratic Socialist (of) Sri Lanka, Colombo
Republic of Sri Lanka Sri Lankan
Sudan (the) the Republic of the Sudan Sudanese Khartoum
Suriname the Republic of Suriname Surinamese Paramaribo
Swaziland the Kingdom of Swaziland = Swazi Mbabane
Sweden the Kingdom of Sweden Swedish, a Swede Stockholm
Switzerland the Swiss Confederation Swiss Berne
Syrian Arab the Syrian Arab Republic Syrian Damascus
Republic (the)
Tanzania: see United Republic of Tanzania (the)
Tajikistan the Republic of Tajikistan Tajik Dushanbe
Thailand the Kingdom of Thailand Thai Bangkok
The former The former Yugoslav of the former Skopje
Yugoslav Republic — Republic of Macedonia Yugoslav Republic
of Macedonia of Macedonia
Togo the Togolese Republic Togolese Lomé
Tonga the Kingdom of Tonga Tongan Nukw’alofa
Trinidad and the Republic of Trinidad of Trinidad and Port-of-Spain
Tobago and Tobago ° Tobago
Tunisia the Republic of Tunisia Tunisian Tunis
Turkey the Republic of Turkey Turkish, a Turk Ankara
Turkmenistan Turkmenistan Turkmen Ashkhabat
Tuvalu Tuvalu Tuvaluan Fongafale
Uganda the Republic of Uganda Ugandan Kampala
Ukraine Ukraine Ukrainian Kiev
United Arab the United Arab Emirates of the United Arab Abu Dhabi
Emirates (the) Emirates

106
