---
doc_id: who-pub-tps-931
doc_title: "WHO Editorial Style Manual"
section_id: page-092
section_title: "Page 92"
pages: 92-92
pdf_page: 92
source_pdf: WHO_PUB_TPS_93.1.pdf
source_sha256: ecc88eee99756755
text_source: ocr
granularity: page
---
F

fact-finding

faecal, faeces

fait accompli

falciparum malaria (but Plasmodium
falciparum)

fallout (n.)

fall out (vb)

false-positive reaction

far-reaching

favour, favourable

federal (authorities etc; in general
contexts)

Federal (with specific titles &
names)

feed (for animals)

feed back (vb)

feedback (n.)

feldsher

fetal, fetus

fibre (not fiber)

fibroadenoma

fibroma

field test (n.)

field-test (vb)

field trial

fieldwork

Fig. (“as shown in Fig. 3")

figure (“the figure above”)

filter

filter-paper

fine-tooth comb (not fine tooth-
comb)

finger-prick (n. & adj.)

first aid (but first-aid kit, etc.)

First World War (not World War 1)

flammable (prefer to inflammable)

flow-chart

flowsheet

focus, focused, focusing

follow up (vb)

follow-up (n. & adj.)

Food and Agriculture Organization
of the United Nations
(not...Agricultural; do not omit
“of the United Nations”)

foodborne

food-chain.

Annex } - Spelling of words that commonly cause difficulty

foodstuff (for people)
foothold
footnote
forbear (vb; refrain from)
forebear (n; ancestor)
forebrain
forego (precede)
foregone (conclusion)
foreseeable
for ever (for always)
forever (continually)
foreword (preface)
forgo (go without)
format, formatted, formatting
(compare combat)
forum (pl. forums)
forward(s) (onward)
fourfold (but 4-fold)
framboesia
freezing-point
fresh water (n.)
freshwater (adj.)
front-line health workers
fulfil, fulfilled, fulfilment
further, furthest (prefer to farther,
farthest)

G

y-isomer (not gamma isomer)

g (gravity; e.g. 3.52)

gas-gangrene

gastroenteritis

gastrointestinal

gauge (n. & vb; not guage)

General Service category (of staff)

genetic (not genetical)

genitourinary

genus (pl. genera)

geographical (not geographic)

geriatric (concerns health &
welfare of the elderly; not a
synonym for aged or senile)

giardiasis

glasnost

goitre (not goiter)

gonococcal

gonococcus (not Gonococcus; see
Neisseria)

87
