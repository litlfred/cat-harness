---
doc_id: who-pub-tps-931
doc_title: "WHO Editorial Style Manual"
section_id: page-052
section_title: "Page 52"
pages: 52-52
pdf_page: 52
source_pdf: WHO_PUB_TPS_93.1.pdf
source_sha256: ecc88eee99756755
text_source: ocr
granularity: page
---
12. Numbers, dates, time and units
of measurement

Numbers

In general, words should be used for the numbers one to nine and at the
beginning of sentences, and figures for 10 and above; however, editors
should use their judgement in individual cases. Figures should never-
theless always be used in specific numerical contexts (e.g. “day 3” or “a
factor of 2”). Numbers that constitute a series or range should usually
be written as figures if at least one of them is greater than nine, for
example “we treated 19 patients with drug A and 7 with drug B”.

When anumber has more than four digits, it should be split by means
of a thin space (not a comma) after every three digits to the left or right
of the decimal point (e.g. 10 000, 0.234 56), but in a table column
containing a mixture of numerals with four digits and numerals with
more than four digits, align them by spacing all of them as for the latter

group.

A decimal point should always be preceded by a figure, if necessary a
zero. Very small numbers are usually best given in exponential nota-
tion, for example 1.6789 x 10°.

The term “billion” is ambiguous (meaning 10° in American and often
10" in British usage) and should be defined or avoided.

When a colon is used to indicate a ratio, there should be a thin space
on either side of it.

Dates
Dates should be written in the form 12 September 1989.

Time

For the time of day, the 24-hour clock should generally be used, e.g.
16:30.

Units of measurement

Measurements should normally be given in SI units in accordance with
The SI for the health professions; for summary tables, see section 11. Most
SI symbols are lower-case letters except those derived from proper
names (e.g. Pa, Gy, W). Symbols are identical in the singular and

7
