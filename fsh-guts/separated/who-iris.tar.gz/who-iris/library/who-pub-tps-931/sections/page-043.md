---
doc_id: who-pub-tps-931
doc_title: "WHO Editorial Style Manual"
section_id: page-043
section_title: "Page 43"
pages: 43-43
pdf_page: 43
source_pdf: WHO_PUB_TPS_93.1.pdf
source_sha256: ecc88eee99756755
text_source: ocr
granularity: page
---
WHO Editorial Style Monval

Further reading

Armstrong Lowe D. A guide to international recommendations on names and symbols
for quantities and on units of measurement. Geneva, World Health Organization,
1975 (Progress in standardization, No. 2).

Baron DN, ed. Units, symbols, and abbreviations; a guide for biological and medical
editors and authors, 4th ed. London, Royal Society of Medicine Services, 1988.

ISO standards handbook: 2. Units of measurement, 2nd ed. Geneva, International
Organization for Standardization, 1982.

Quantities, units and symbols, 2nd ed. London, The Royal Society, 1975 (amend-
ment 1981).

The SI for the health professions. Geneva, World Health Organization, 1977
(updated and reprinted 1982).

Abbreviations in common use

The list below gives some common abbreviations with indications of

their use.

and &!

as desired (ad libitum) ad lib
compare (confer) cf.
continued cont.
edition ed!
editor(s) ed., eds!

et alii etal.

et cetera etc.

et sequentia et seq.
figure(s) Fig., Figs?
for example (exempli gratia) e.g.
manuscript(s) MS, MSS
nota bene N.B.
number(s) no., No., Nos
page(s) P.s Pp.

per centum per cent, %
revised, revision tev.

that is (id est) ie.
Volume(s) Vol!

! To be used in bibliographic references (see section 9).
2 To be used (when appropriate to the style of the book) for a figure, and in cross-
references in the text to numbered figures.
