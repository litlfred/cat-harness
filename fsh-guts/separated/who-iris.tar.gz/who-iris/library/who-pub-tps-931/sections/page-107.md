---
doc_id: who-pub-tps-931
doc_title: "WHO Editorial Style Manual"
section_id: page-107
section_title: "Page 107"
pages: 107-107
pdf_page: 107
source_pdf: WHO_PUB_TPS_93.1.pdf
source_sha256: ecc88eee99756755
text_source: ocr
granularity: page
---
WHO Editorial Style Manual

Short name Full name Adjective/People Capital city
Germany the Federal Republic German Berlin!

of Germany
Ghana the Republic of Ghana Ghanaian Accra
Greece the Hellenic Republic Greek Athens
Grenada Grenada Grenadian. St George’s
Guatemala the Republic of Guatemala Guatemalan Guatemala City
Guinea the Republic of Guinea Guinean Conakry
Guinea-Bissau the Republic of (of) Guinea-Bissau Bissau

Guinea-Bissau
Guyana the.Republic of Guyana Guyanese Georgetown
Haiti the Republic of Haiti Haitian Port-au-Prince
Holy See (the)? the Holy See of the Holy See
Honduras the Republic of Honduras — Honduran Tegucigalpa
Hungary the Republic of Hungary Hungarian Budapest
Iceland the Republic of Iceland Icelandic, Reykjavik

an Icelander
India the Republic of India Indian New Delhi
Indonesia the Republic of Indonesia Indonesian Jakarta
Tran (Islamic the Islamic Republic of Iran Iranian Teheran
Republic of)?
Traq the Republic of Iraq Iraqi Baghdad
Ireland Ireland Trish, the Irish, Dublin
an Irishman.

Israel the State of Israel Israeli
Italy the Italian Republic Italian Rome
Ivory Coast (the): see Cote dIvoire
Jamaica Jamaica Jamaican Kingston
Japan Japan Japanese Tokyo
Jordan the Hashemite Kingdom Jordanian Amman

of Jordan

1 Seat of Government: Bonn/Berlin.

2 In United Nations documents the term “Holy See”, not “Vatican City State”, should be used,
except in texts concerning the International Telecommunication Union and the Universal
Postal Union — the two organizations in which the latter term is the accepted designation.

3 For purposes other than alphabetical lists or name-plates, the following form should be used: the
Islamic Republic of Iran.

102
