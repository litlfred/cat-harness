---
doc_id: who-pub-tps-931
doc_title: "WHO Editorial Style Manual"
section_id: page-080
section_title: "Page 80"
pages: 80-80
pdf_page: 80
source_pdf: WHO_PUB_TPS_93.1.pdf
source_sha256: ecc88eee99756755
text_source: ocr
granularity: page
---
zation ot of Member States, for example overt criticism of named
national governments or criticism relating to WHO's internal organi-
zation and to the functioning of specified technical units. Over-
generalizations concerning particular professional or population groups
and legally contentious issues should be avoided. In case of doubt about
specific statements, LEG should be consulted.

Specifications

Specifications and similar requirements drafted by a meeting of experts
are not necessarily endorsed by WHO and should not be described as
WHO specifications unless they have been adopted by the World
Health Assembly or the Executive Board. They may, however, be
described as “specifications published by WHO”.

Definitions

Definitions recommended by an expert group should not conflict with
definitions previously published by WHO, unless the group considered
that previous definitions should be superseded, when this should be
explicitly stated. A phrase such as “the Expert Committee adopted the
following definitions for the purposes of its report” may be useful when
the status and scope of applicability of definitions are not clear.

Headings

Headings should be sufficiently numerous to separate clearly the
various topics discussed and to facilitate reading, but excessive use of
third-order and fourth-order headings should be avoided. A number-
ing system is normally used (1, 1.1, 1.2, 1.2.1, etc.) but should not be
extended beyond third-order headings.

Recommendations

The recommendations of an expert group are often split into those
directed to WHO and those directed to Member States. The former
frequently need to be reworded so as to advise the Director-General on
future programme activities without calling upon him to use WHO
staff, services or funds in a specified way. Recommendations of the
form “WHO should fund. ..” and “WHO should establish a programme
for...” are not acceptable. Direct recommendations to other United
Nations bodies and to nongovernmental organizations should be
avoided by appropriate rewording, for example “WHO should encour-
age/collaborate with/urge UNICEF...” rather than “UNICEF
should...”.

Technical reports

5
