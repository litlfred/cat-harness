---
doc_id: who-pub-tps-931
doc_title: "WHO Editorial Style Manual"
section_id: page-016
section_title: "Page 16"
pages: 16-16
pdf_page: 16
source_pdf: WHO_PUB_TPS_93.1.pdf
source_sha256: ecc88eee99756755
text_source: ocr
granularity: page
---
3. Punctuation

This is a large subject where personal taste and common sense are more
important than any rules. Appropriate punctuation will ease reading
and clarify meaning, and this should be its purpose.

A well written running text should require only the minimum of
punctuation in order to read clearly and sensibly. If much punctuation
is required, it is probably a good indication that the texthas been badly
written and should be revised rather than heavily punctuated. Particu-
larly in scientific writing, unnecessary punctuation should be avoided
if the meaning is clear.

The punctuation guidelines below do not cover the special require-
ments of references and bibliographies (see section 9), or those of
indexes.

Care should be taken to make sure that, when appropriate, punctua-
tion marks are printed in the same style and type font as the rest of the
text in which they appear.

Very few specific examples of the use of punctuation marks appear in
this section, since they are to be found in abundance in the books listed
on page 15.

Full point (period)

A full point should be used to separate statements between which there
is no true continuity of thought. This results in shorter, more concise
sentences, thus avoiding the temptation to include too much in a
single sentence.

No full point is required for column headings, running heads, chapter
titles and legends, or after abbreviations ending with the final letter of
the word (see “Abbreviations and symbols”, section 11, for examples).

An abbreviating full point, as at the end of etc. and Co., is omitted
before a full point ending a sentence. Similarly, a stronger punctuation
mark, such as a question mark or an exclamation mark, will replace a
full point at the end of a sentence.

Ellipsis points (three spaced dots) signify either omitted material or
faltering speech. Interruptions or abrupt changes in thought should be
indicated by a dash (em rule).

FT
