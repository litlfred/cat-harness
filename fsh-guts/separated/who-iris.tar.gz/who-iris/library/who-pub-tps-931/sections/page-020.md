---
doc_id: who-pub-tps-931
doc_title: "WHO Editorial Style Manual"
section_id: page-020
section_title: "Page 20"
pages: 20-20
pdf_page: 20
source_pdf: WHO_PUB_TPS_93.1.pdf
source_sha256: ecc88eee99756755
text_source: ocr
granularity: page
---
Question mark

Question marks are necessary at the end of direct but not of indirect
questions.

Requests in question form for the sake of politeness, e.g. would you
kindly tefl me whether..., usually have question marks, although they
are not strictly necessary.

Further reading

Many excellent examples of correct usage of the above punctuation
marks, and much more besides, are to be found in the following:

Butcher J. Copy-editing. The Cambridge handbook for authors, editors and indexers,
3rd ed. Cambridge, Cambridge University Press, 1992.

Carey GV. Mind the stop: brief guide to punctuation. Harmondsworth, Penguin
Books, 1971.

Council of Biology Editors Style Manual Committee. Scientific style and format: the
CBE manual for authors, editors, and publishers, 6th ed. Cambridge, Cambridge
University Press, 1994.

Gowers E (rev. Greenbaum S, Whitcut J). The complete plain words, 3rd ed.
London, HMSO, 1986.

Hart's rules for compositors and readers at the University Press Oxford, 39th ed.
Oxford, Oxford University Press, 1983.

Strunk W, White EB. The elements of style, 3rd ed. Macmillan, New York, 1978.

The Chicago manual of style: the essential guide for writers, editors, and publishers,
14th ed. Chicago, University of Chicago Press, 1993.

Punctuation

15
