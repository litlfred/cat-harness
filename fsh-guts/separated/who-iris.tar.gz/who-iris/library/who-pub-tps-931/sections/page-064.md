---
doc_id: who-pub-tps-931
doc_title: "WHO Editorial Style Manual"
section_id: page-064
section_title: "Page 64"
pages: 64-64
pdf_page: 64
source_pdf: WHO_PUB_TPS_93.1.pdf
source_sha256: ecc88eee99756755
text_source: ocr
granularity: page
---
Scientific terminology

Haemoglobins

The term “haemoglobin” is usually represented by the symbol Hb and
the various types of haemoglobin by capital letters or the names of the
laboratories, hospitals or places in which they were found (e.g. Hb F,
Hb S, Hb Hammersmith). The major and minor adult haemoglobins
are designated Hb A and Hb A, The four polypeptide chains of normal
human haemoglobin are designated by the Greek letters a, 8, y, and 8
and the paired chains in the form o,8,, 0,8, etc. For abnormal
haemoglobins, the locations of amino acid differences may be indi-
cated by designating the chain, the numbered position on it, the helix
position in parentheses and the amino acid substitution, for example:

087(F8)His > Tyr for Hb M Iwate.

Further reading
International Society of Haematology. Nomenclature of abnormal haemoglobins.

[Recommendations unanimously accepted at the Tenth International Congress
of Haematology, Stockholm, 1964.] British journal of haematology, 1965, 11:121-122.

Tenth International Congress of Haematology. Nomenclature of hacmoglobins.
British medical journal, 1964, 2:1258.

Immunology

Immunoglobulins
Immunoglobulins should be represented by the symbol “Ig” and a
capital letter designating the specific class:

IgG IgA IgM IpD IgE.

Subclasses are indicated by a number attached to the class symbol, for
example:

IgG2 IgM3.

Further reading
An extension of the nomenclature for immunoglobulins. Bulletin of the Worid
Health Organization, 1969, 41:975-978.

Nomenclature for human immunoglobulins. Bulletin of the World Health Organiza-
tion, 1964, 30:447-450.

Nomenclature of human immunoglobulins. Bulletin of the World Health Organiza-
tion, 1973, 48:373.

Notation for genetic factors of human immunoglobulins. Bulletin of the World
Health Organization, 1965, 33:721—-724.

Notation for human immunoglobulin subclasses. Bulletin of the World Health
Organization, 1966, 35:953.

Rowe DS. Nomenclature of immunoglobulins. Nature, 1970, 228:509-511.

59
