---
doc_id: who-pub-tps-931
doc_title: "WHO Editorial Style Manual"
section_id: page-031
section_title: "Page 31"
pages: 31-31
pdf_page: 31
source_pdf: WHO_PUB_TPS_93.1.pdf
source_sha256: ecc88eee99756755
text_source: ocr
granularity: page
---
WHO Editorial Style Manual

Ina report of a meeting, a disclaimer along the following lines should
be used (in Technical Reports, this appears on the title page):

This report contains the collective views of an international group
of experts, and does not necessarily represent the decisions or the
stated policy of the World Health Organization.

Disclaimers are intended to protect the Organization, but particular
care should nevertheless be taken with the wording of text dealing
with politically or legally sensitive issues (see section 16).

Reproducing previously published material

The originating unit is responsible for obtaining the permission of the
copyright holders — publisher or author or both — to reproduce any
previously published material. Where necessary, editors should draw
the author’s attention to the need to obtain permission. A standard
letter is available for this (see WHO Manual VIII.2, Annex C). The
originals of the letters granting such permission should be sent to PUB
with the manuscript, if possible, or as soon as received.

Quotations from written material protected under copyright are nor-
mally considered to be “fair use”, provided they are of reasonable
length and the source is mentioned. However, drawings, tables,
photographs, etc. may not be used without permission, even if the copy
has been altered slightly.

Material published in the USA by federal or publicly funded agencies,
e.g. Centers for Disease Control and Prevention and National Insti-
tutes of Health, is considered to be in the public domain and not
protected by copyright. The source should, in any case, be acknowl-

edged.

26
