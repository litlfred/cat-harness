---
doc_id: who-pub-tps-931
doc_title: "WHO Editorial Style Manual"
section_id: page-030
section_title: "Page 30"
pages: 30-30
pdf_page: 30
source_pdf: WHO_PUB_TPS_93.1.pdf
source_sha256: ecc88eee99756755
text_source: ocr
granularity: page
---
8. Copyright and disclaimers

When a manuscript is accepted for publication by WHO, it becomes
the property of the Organization, the author ceding the copyright. The
following copyright notice and disclaimers are printed on the verso of
the title page of all headquarters publications:

The World Health Organization welcomes requests for permission
to reproduce or translate its publications, in part or in full. Applica-
tions and enquiries should be addressed to the Office of Publica-
tions, World Health Organization, Geneva, Switzerland, which
will be glad to provide the latest information on any changes made
to the text, plans for new editions, and reprints and translations
already available.

© World Health Organization 19xx

Publications of the World Health Organization enjoy copyright
protection in accordance with the provisions of Protocol 2 of the
Universal Copyright Convention. All rights reserved.

The designations employed and the presentation of the material in
this publication do not imply the expression of any opinion what-
soever on the part of the Secretariat of the World Health Organi-
zation concerning the legal status of any country, territory, city or
area or of its authorities, or concerning the delimitation of its
frontiers or boundaries.

The mention of specific companies or of certain manufacturers’
products does not imply that they are endorsed or recommended by
the World Health Organization in preference to others of a similar
nature that are not mentioned. Errors and omissions excepted, the
names of proprietary products are distinguished by initial capital
letters.

It is essential to include the copyright symbol ©. The date on the
copyright notice should be the year of publication, as given on the title
page of the book.

If appropriate, the following disclaimers may be added:

The authors alone are responsible for the views expressed in this
publication. Where the designation “country or area” appears in the
headings of tables, it covers countries, territories, cities, or areas.
Dotted lines on maps represent approximate border lines for which
there may not yet be full agreement.

25
