---
doc_id: who-pub-tps-931
doc_title: "WHO Editorial Style Manual"
section_id: page-013
section_title: "Page 13"
pages: 13-13
pdf_page: 13
source_pdf: WHO_PUB_TPS_93.1.pdf
source_sha256: ecc88eee99756755
text_source: ocr
granularity: page
---
WHO Editorial Style Manual

Capitalization

Too many capital letters break the flow of the eye across a sentence and
down acolumn of type. However, proper names, titles and institutions
require capitals. Descriptive appellations, such as administrative posts,
do not, unless the result would appear odd or confusing.

The trade names of drugs and other proprietary products, e.g. Pyrex and
Vaseline (petroleum jelly preferred), require an initial capital letter.
Generic terms in the Linnaean classification also take an initial capital
letter, e.g. Staphylococcus aureus, Trypanosoma, Schistosoma, but trypa-
nosome, schistosome, etc.

Article, book and journal titles in references need not be capitalized,
e.g. Social science and medicine, except when they contain the name of
an association or organization, e.g. Bulletin of the World Health Organi-
zation, Journal of the American Medical Association.

The following words and expressions used frequently within WHO
normally require capitalization:

Associate Member

Constitution (of WHO)

(Eighth) General Programme of Work

Forty-... World Health Assembly

Global Strategy for Health for All by the Year 2000

Member (country)

Member State

officials (specific): President, Vice-President, Chairman, Rappor-
teur, Secretary

the Organization (WHO)

Region [of WHO] (cap. in specific reference, e.g. “in the European
Region”)

Regional Committee (specific)

Regional Director(s) (specific)

Regional Office (specific), but regional offices (pl.)

Secretariat (WHO)

Some other commonly used words are capitalized only when used
specifically, e.g. a government, but the French Government; a minis-
try, but the Ministry of Health; a department, but the Department of
the Environment.
