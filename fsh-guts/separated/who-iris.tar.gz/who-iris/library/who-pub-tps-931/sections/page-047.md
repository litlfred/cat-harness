---
doc_id: who-pub-tps-931
doc_title: "WHO Editorial Style Manual"
section_id: page-047
section_title: "Page 47"
pages: 47-47
pdf_page: 47
source_pdf: WHO_PUB_TPS_93.1.pdf
source_sha256: ecc88eee99756755
text_source: ocr
granularity: page
---
WHO Editorial Style Manual

Abbreviations used in the medical sciences

Extensive lists of abbreviations used in the medical sciences are given
in the following publications:

Heister R. Dictionary of abbreviations in medical sciences. Berlin,
Springer Verlag, 1989.

Steen EB. Bailligre’s abbreviations in medicine, 5th ed. London,
Baillitre Tindall, 1984.

The following acronyms and abbreviations are in common use in the
medical sciences; those marked with an asterisk do not usually need to

be defined.

ACTH adrenocorticotropic hormone

ADP* adenosine diphosphate

AIDS acquired immunodeficiency syndrome
AMP* adenosine monophosphate

ATP* adenosine triphosphate

BCG* bacille Calmette-Guérin (vaccine)
BMR basal metabolic rate

BOD biochemical oxygen demand

BP blood pressure

CAAT computer-assisted axial tomography
cDNA complementary deoxyribonucleic acid
CIEP counterimmunoelectrophoresis

CMV cytomegalovirus

CNS central netvous system

CSF cerebrospinal fluid

DNA* deoxyribonucleic acid

DTP diphtheria—tetanus—pertussis vaccine
EBV Epstein—Barr virus

EGG electrocardiogram, electrocardiography
ECT electroconvulsive therapy

ED,, median effective dose

EEG electroencephalogram, electroencephalography

ELICT enzyme-linked immunocytochemical technique
ELIEDA = enzyme-linked immunoelectron diffusion assay

ELISA enzyme-linked immunosorbent assay

EMIT enzyme multiplication immunoassay technique

Fi first filial generation

FAST fluorescent antibody staining technique; fluoro-
allergosorbent test

FAT fluorescent antibody technique (test)

42
