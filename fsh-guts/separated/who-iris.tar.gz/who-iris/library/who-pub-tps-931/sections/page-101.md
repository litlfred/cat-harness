---
doc_id: who-pub-tps-931
doc_title: "WHO Editorial Style Manual"
section_id: page-101
section_title: "Page 101"
pages: 101-101
pdf_page: 101
source_pdf: WHO_PUB_TPS_93.1.pdf
source_sha256: ecc88eee99756755
text_source: ocr
granularity: page
---
WHO Editorial Style Manual : _

teratogen, teratogenic

test-tube

textbook

text processing, text processor

thermonuclear

thermostable, thermostability

through (not thru)

tick-borne

time-limit

time-scale

timetable

title page

ton (should be preceded by “long”
or “short”)

tonne (not “metric ton” or “metric
tonne”)

topsoil

total (vb), totalled, totalling

towards (not toward)

traffic, trafficker, trafficking

tranquillize, tranquillizer

transnational

transplacental

travel, travelled, travelling

Trypanosoma, trypanosome,
trypanosomiasis, trypanosomal

tsetse fly

tumefaction, tumefy

tumour, tumorigenic

turn out (vb)

turnout (n.)

turn over (vb)

turnover (n.)

twofold (but 2-fold)

two-thirds

typesetting

tyre (n.)

U

ultrafiltration

ultra-low-volume formulations
(abbr. = ULV)

ultramicroscopic

ultraspecific

ultraviolet

unbiased

uncooperative

uncoordinated

underdeveloped

underestimated

undergraduate

underprivileged

underrate

underserved (insufficiently served)

underuse

underutilize

under way (not underway)

underweight (adj.)

undeserved (unmerited)

unequivocal, unequivocally (not
unequivocable, unequivocably)

UNESCO (caps; but Unesco Press)

UNICEF (caps)

United Kingdom (net UK)

United Nations (not UN)

update

up-to-date (adj.; but it is up to date)

urine analysis (not urinalysis)

V

Vacutainer (trade name, requires
cap.)

vaporize, vapour, vaporizer

Vaseline (trade name, requires cap.;
prefer petroleum jelly)

vasodilator

vasomotor

vector-borne

venepuncture (not venipuncture)

venesection.

ventrolateral

via

vice-chairman, etc.

vice versa

vigorous, vigour

viral

virile

vis-a-vis

vitamin A, etc. (not Vitamin A,
etc.) 7

viva voce

viz. (prefer namely)

vulvovaginitis

96
