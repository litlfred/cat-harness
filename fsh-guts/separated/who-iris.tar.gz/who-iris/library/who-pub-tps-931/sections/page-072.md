---
doc_id: who-pub-tps-931
doc_title: "WHO Editorial Style Manual"
section_id: page-072
section_title: "Page 72"
pages: 72-72
pdf_page: 72
source_pdf: WHO_PUB_TPS_93.1.pdf
source_sha256: ecc88eee99756755
text_source: ocr
granularity: page
---
Non-discriminatory language

The occasional exception

There will be occasions when a term including “man” may be unavoid-
able, even when the context is not limited to men. An obvious
example is “man-made disasters”, for which no generally acceptable
alternative is available. Use of the word “Chairman” rather than the
more general “Chair” or “Chairperson” may be obligatory. It would be
wrong to be over-dogmatic in this area: editors should exercise their
judgement, based on the principles outlined here.

Avoiding other types of discrimination

In assessing whether a particular text could cause offence on racial or
cultural terms, try substituting your own ethnic or cultural group for
that under discussion. If the revised text causes you to feel belittled or
offended, you can safely assume that the original was guilty of bias.

Other forms of language that may cause offence include “ageist” terms
such as “geriatrics”. Avoid this type of discrimination by substituting
less impersonal words such as “older people” or “elderly patients”. Care
should also be taken in describing people with disabilities; suggestions
for appropriate terminology are given in the Guidelines produced by
the Research and Training Center on Independent Living.

People who are ill should be referred to as “patients”: use “diabetic
Pp Pi

patients” or “patients with hypertension” rather than the dehumaniz-
ing “diabetic cases” or “hypertensives”.

Avoid terms such as “the western world” and “Middle (or Far) East”
which imply that everything is viewed from the standpoint of Western
Europe. There is also an increasing tendency for the terms “North” and
“South” to be used to imply a particular stage of development. Usage
of all such terms should be restricted to a geographical context only.
Similarly, refer to “developing countries” rather than to “underdevel-
oped countries” or “the Third World”.

Further reading

Guidelines for reportingand writing about people with disabilities, 3rd ed. Lawrence, KS,
Research and Training Center on Independent Living, 1990.

Miller C, Swift K. The handbook of non-sexist writing. London, The Women’s Press,
1981.

Publication manual of the American Psychological Association, 4th ed. Washington,
DC, American Psychological Association, 1994.

Spender D. Man made language, 2nd ed. London, Routledge & Kegan Paul,
1985:153-154.

67
