---
doc_id: who-pub-tps-931
doc_title: "WHO Editorial Style Manual"
section_id: page-109
section_title: "Page 109"
pages: 109-109
pdf_page: 109
source_pdf: WHO_PUB_TPS_93.1.pdf
source_sha256: ecc88eee99756755
text_source: ocr
granularity: page
---
WHO Editorial Style Manual

Short name Full name Adjective/People Capital city
Micronesia the Federated States of the Federated Palikir
(Federated States of)! of Micronesia States of Micronesia
Moldova: see Republic of Moldova (the)
Monaco the Principality of Monaco Monegasque Monaco
Mongolia Mongolia Mongolian Ulaanbaatar
Morocco the Kingdom of Morocco Moroccan Rabat
Mozambique the Republic of Mozambique Mozambican Maputo
Myanmar the Union of Myanmar of Myanmar Yangon
Namibia the Republic of Namibia Namibian Windhoek
Nauru the Republic of Nauru Nauruan Yaren
Nepal the Kingdom of Nepal Nepalese Kathmandu
Netherlands (the) the Kingdom of Netherlands, Amsterdam?
the Netherlands a Netherlander
New Zealand New Zealand (of) New Zealand, Wellington
a New Zealander
Nicaragua the Republic of Nicaragua Nicaraguan Managua
Niger (the) the Republic of the Niger (of the) Niger Niamey
Nigeria the Federal Republic Nigerian Abuja
of Nigeria
Niue the Republic of Niue of Niue Alofi
Norway the Kingdom of Norway Norwegian Oslo
Oman the Sultanate of Oman Omani Muscat
Pakistan the Islamic Republic (of) Pakistan, Islamabad
of Pakistan a Pakistani
Palau the Republic of Palau of Palau Koror
Panama the Republic of Panama Panamanian Panama City
Papua New Guinea Papua New Guinea (of) Papua New Port Moresby

Guinea, a Papua
New Guinean

Paraguay the Republic of Paraguay Paraguayan Asuncién
Peru the Republic of Peru Peruvian Lima

| For purposes other than alphabetical lists and name-plates, the following form should be used:
the Federated States of Micronesia.
2 Seat of Government: The Hague.

104
