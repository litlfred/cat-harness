---
doc_id: who-pub-tps-931
doc_title: "WHO Editorial Style Manual"
section_id: page-034
section_title: "Page 34"
pages: 34-34
pdf_page: 34
source_pdf: WHO_PUB_TPS_93.1.pdf
source_sha256: ecc88eee99756755
text_source: ocr
granularity: page
---
Reference lists and bibliographies

Monograph in a series
Cancer pain relief and palliative care. Report of aWHO Expert Commit-
tee. Geneva, World Health Organization, 1990 (WHO Technical
Report Series, No. 804).

WHO Expert Committee on Biological Standardization. Fortieth Report.
Geneva, World Health Organization, 1990 (WHO Technical Re-
port Series, No. 800).

Corporate author
Royal Marsden Hospital Bone-Marrow Transplantation Team.
Failure of syngeneic bone-marrow graft without preconditioning in
post-hepatitis marrow aplasia. Lancet, 1977, 2:242-244.

If the corporate author is also the publisher, it need only be mentioned
once. Where a WHO publication has no named author, the World
Health Organization should be shown as the publisher:

The international pharmacopoeia. Vol. 3. Quality specifications. Geneva,
World Health Organization, 1988.

Dissertation or thesis
Cairns RB. Infrared spectroscopic studies of solid oxygen [Disserta-
tion]. Berkeley, CA, University of California, 1965.

Published proceedings paper
DuPont B. Bone marrow transplantation in severe combined immu-
nodeficiency with an unrelated MLC compatible donor. In: White
HJ, Smith R, eds. Proceedings of the third annual meeting of the
International Society for Experimental Hematology. Houston, TX,
International Society for Experimental Hematology, 1974:44-46.

Unpublished document (if available to readers)
Guidelines for leishmaniasis control at regional and subregional level.
Geneva, World Health Organization, 1988 (unpublished docu-
ment WHO/LEISH/88.25; available on request from Division of
Control of Tropical Diseases, World Health Organization, 1211
Geneva 27, Switzerland).

Foreign language reference
Jordan JR. Desarrollo psicomotor del nifio. [Psychomotor develop-
ment of the child.] In: Temas de pediatria. [Aspects of paediatrics. ]
Havana, Editora Universitaria, 1976.

29
