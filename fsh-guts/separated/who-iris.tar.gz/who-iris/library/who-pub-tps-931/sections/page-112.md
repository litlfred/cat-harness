---
doc_id: who-pub-tps-931
doc_title: "WHO Editorial Style Manual"
section_id: page-112
section_title: "Page 112"
pages: 112-112
pdf_page: 112
source_pdf: WHO_PUB_TPS_93.1.pdf
source_sha256: ecc88eee99756755
text_source: ocr
granularity: page
---
Annex 2 - Member States

Short name

Full name

Adjective/People Capital city

United Kingdom
of Great Britain
and Northern
Ireland (the)!

United Republic
of Tanzania (the)

United States of
America (the)?
Uruguay

Uzbekistan

Vanuatu

the United Kingdom
of Great Britain
and Northern Ireland

the United Republic
of Tanzania

the United States
of America

the Eastern Republic
of Uruguay

the Republic of Uzbekistan
the Republic of Vanuatu

Vatican City State: see Holy See

Venezuela
Viet Nam

Yemen

Yugoslavia

the Republic of Venezuela

the Socialist Republic
of Viet Nam

the Republic of Yemen

Yugoslavia

Zaire: see Democratic Republic of the Congo (the)

Zambia

Zimbabwe

the Republic of Zambia
the Republic of Zimbabwe

(of the) United London
Kingdom (of Great

Britain and Northern
Ireland), British

Tanzanian Dodoma

(of the) United Washington,
States (of America), DC

American

Uruguayan Montevideo
Uzbek Tashkent

of Vanuatu Vila
Venezuelan Caracas
Vietnamese Hanoi

Yemeni, a Yemenite Sana’a
5

Yugoslav Belgrade
Zambian Lusaka
Zimbabwean Harare

! The full name should be used on title pages, in signatures and in recording nominations, elections
and votes. Once the full name has been mentioned or where space is limited (as in a table for
instance), the following shorter form may be used: the United Kingdom.

2 Once the full name has been used or where space is limited (as in a table for instance), the
following shorter forms may be used: the United States, USA.

107
