---
doc_id: who-pub-tps-931
doc_title: "WHO Editorial Style Manual"
section_id: page-120
section_title: "Page 120"
pages: 120-120
pdf_page: 120
source_pdf: WHO_PUB_TPS_93.1.pdf
source_sha256: ecc88eee99756755
text_source: ocr
granularity: page
---
Annex 4

Terms used for manuscript mark-up and
proof correction (English/French)

English French English French
Typography in 2 columns sur 2 colonnes
typeface caractére landscape layout a litalienne
italic italique not justified en drapeau
roman romain full width pleine justification
bold gras ona fold-out page en dépliant
medium mi-gras tint trame
light léger screened tramé
small capitals petites capitales
(large) capitals capitales Signs, symbols, etc.
lower case bas de casse (b.d.c.) dash, em rule tiret
diphthong lettres accouplées en rule [does not 1/2 moins
in smaller type plus petit corps teally exist in :
8pt, 10pt c.8,c.10 French]
hyphen trait @'union
Manuscript/proof minus sign moins
mark-up plus sign signe plus
page make-up mise en page division sign symbole de division
cover couverture multiplication sign signe de multipli-
spine dos [note possible cation
title page page titre confusion with
half-title page page faux-titre raised point]
verso, left-hand verso raised point point centré (signe
page [medial de multiplication)

recto, right-hand
page

galley proof

page proofs

ozalid

blank page

title, heading

running head

paragraph

footnote

recto

épreuve en placard
épreuves en pages
ozalide
page blanche
titre
titre courant
alinéa
note en bas de

la page

multiplication

point, water of

crystallization |
solidus

(chin) rule
subscript
superscript
dotted line
brace
parenthesis

barre oblique, barre
de fraction

filet (maigre)

inférieur

supérieur

ligne pointillée

accolade

parenthése

nS
