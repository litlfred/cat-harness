---
doc_id: who-pub-tps-931
doc_title: "WHO Editorial Style Manual"
section_id: page-049
section_title: "Page 49"
pages: 49-49
pdf_page: 49
source_pdf: WHO_PUB_TPS_93.1.pdf
source_sha256: ecc88eee99756755
text_source: ocr
granularity: page
---
WHO Editorial Style Manual ‘

Units of currency

Lists of the official basic units of currency and the appropriate currency
abbreviations are given in:

Currency units. New York, United Nations, 1993 (Terminology
bulletin no. 346).

The currencies listed are those officially in use as at 19 March 1993 and
may be subject to change. Further information can be obtained from
CTT. The abbreviations used for the various currencies are also given
in the following publication:

Hunter B, ed. The Statesman’s year-book: statistical, political and
economic account of the states of the world for the year 1997-1998. New
York, St Martin's Press, 1997.

When two or more countries use the same name for their currencies,
the appropriate distinguishing adjective should be used at first men-
tion, or throughout the text if confusion is possible: two million Irish
pounds, six million pounds sterling.

When the monetary unit is written in full, it should follow the number
for the amount, as in the examples above, but when the abbreviation
is used, it should always precede the amount. Where a symbol is used
to represent the monetary unit, there should be no space between the
symbol and the amount, for example:

£19.95.
Where the abbreviation is a letter or letters or a combination of

letter(s) and symbol, there should be one space between the abbrevia-
tion and the amount, for example:

US$ 6000.

WHO's three-letter currency codes (GBP, USD, CHF, etc.) are for
internal use only, and should not appear in publications.

44
