---
doc_id: hl7-2023-fhir-r5-testplan
doc_title: "FHIR R5 (5.0.0) — TestPlan resource"
section_id: s001-source-testplan-testplan-introduction-xml
section_title: "source/testplan/testplan-introduction.xml"
file: "source/testplan/testplan-introduction.xml"
lines: 1-44
source_sha256: d8407666c9003762
granularity: file
---
```xml
<div xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.w3.org/1999/xhtml ../../schema/fhir-xhtml.xsd" xmlns="http://www.w3.org/1999/xhtml">

<div>
<a name="bnc"></a>
<h2>Scope and Usage</h2>
<p>
The TestPlan is a canonical resource that defines how an system or specifications (which can be represented by FHIR artifacts or by narrative) are to be tested. It contains the business- and planning-language aspects of test planning, around the TestScript, which handles part of the test execution.
</p>
<p>A TestPlan describes the purpose, the dependencies, scope, test environment, test framework, test output, etc. It contains test cases which can describe narrative test enter/exit criteria, test data, etc. (enter criteria are a common name for preconditions, exit criteria are the criteria for the tests to finish - successfully or unsuccessfully e.g. "Unable to Test".
</p>
<p>
The TestPlan supports traditional testing as well as agile testing (TDD, BDD). 
It contains pointers to the data itself, or the information for the test data to be obtained, e.g. the instructions for synthetic data generation.
</p>
<p>
TestPlans can depend or extend other test plans - TestPlan is a canonical resource to allow reuse - one example of this would be a national FHIR specification (as an IG or a Requirement) that decribes that a System has to be conformant to IHE profiles, WHO datasets, ISO IDMP models, OpenHIE specifications, and national terminologies, in one of the national languages. If any of these specifications  have a TestPlan resource, such TestPlans can be reused, combined, and extended downstream.
</p>  
  <br/>

</div>


<div>
<h2>Boundaries and Relationships</h2>
<p>
The TestPlan is related to, but not overlapping, the TestScript resource, as the TestPlan is intended to contain the planning and non-technical part of the testing, which is necessary to describe "what to test". The TestScript describes "how to test". The TestPlan is necessary to be maintained from a Business perspective, - test criteria can be expected to be defined or validated by business-oriented  authors, while testscripts can be defined by technical test teams.
</p>

<p>
A TestPlan resource can be associated with any canonical resource. This includes, but is not limited to, the ImplementationGuide resource - a TestPlan can be defined for an entire Implementation Guide, or for some of the artifacts in the Implementation Guide, like an AcrotDefinition, Requirements, etc.
  </p>
</div>


<!-- (optional):
<div>
<h2>Background and Context</h2>
<p>
Provides additional detail on exactly how the resource is to be used
</p>
</div>
-->

</div>
```
