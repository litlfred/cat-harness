---
doc_id: hl7-2023-fhir-r5-testplan
doc_title: "FHIR R5 (5.0.0) — TestPlan resource"
section_id: s006-source-testplan-codesystem-testplan-status-xml
section_title: "source/testplan/codesystem-testplan-status.xml"
file: "source/testplan/codesystem-testplan-status.xml"
lines: 1-57
source_sha256: 3be01c655594fb59
granularity: file
---
```xml
<?xml version="1.0" encoding="UTF-8"?><CodeSystem xmlns="http://hl7.org/fhir">
  <id value="testplan-status"/>
  <meta>
    <profile value="http://hl7.org/fhir/StructureDefinition/shareablecodesystem"/>
  </meta>
  <extension url="http://hl7.org/fhir/StructureDefinition/structuredefinition-wg">
    <valueCode value="oo"/>
  </extension>
  <extension url="http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status">
    <valueCode value="trial-use"/>
  </extension>
  <extension url="http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm">
    <valueInteger value="0"/>
  </extension>
  <url value="http://hl7.org/fhir/testplan-status"/>
  <version value="5.0.0"/>
  <name value="TestPlanStatus"/>
  <title value="TestPlanStatus"/>
  <status value="draft"/>
  <experimental value="false"/>
  <date value="2021-01-05T10:01:24+11:00"/>
  <publisher value="HL7 (FHIR Project)"/>
  <contact>
    <telecom>
      <system value="url"/>
      <value value="http://hl7.org/fhir"/>
    </telecom>
    <telecom>
      <system value="email"/>
      <value value="fhir@lists.hl7.org"/>
    </telecom>
  </contact>
  <description value="The status of the TestPlan."/>
  <caseSensitive value="true"/>
  <valueSet value="http://hl7.org/fhir/ValueSet/testplan-status"/>
  <content value="complete"/>
  <concept>
    <code value="draft"/>
    <display value="Draft"/>
    <definition value="The existence of the report is registered, but it is still without content or only some preliminary content."/>
  </concept>
  <concept>
    <code value="requested"/>
    <display value="Requested"/>
    <definition value="The inventory report has been requested but there is no data available."/>
  </concept>
  <concept>
    <code value="active"/>
    <display value="Active"/>
    <definition value="This report is submitted as current."/>
  </concept>
  <concept>
    <code value="entered-in-error"/>
    <display value="Entered in Error"/>
    <definition value="The report has been withdrawn following a previous final release.  This electronic record should never have existed, though it is possible that real-world decisions were based on it."/>
  </concept>
</CodeSystem>
```
