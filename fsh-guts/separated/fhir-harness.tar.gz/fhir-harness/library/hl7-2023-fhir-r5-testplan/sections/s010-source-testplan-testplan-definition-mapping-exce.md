---
doc_id: hl7-2023-fhir-r5-testplan
doc_title: "FHIR R5 (5.0.0) — TestPlan resource"
section_id: s010-source-testplan-testplan-definition-mapping-exce
section_title: "source/testplan/testplan-definition-mapping-exceptions.xml"
file: "source/testplan/testplan-definition-mapping-exceptions.xml"
lines: 1-125
source_sha256: d8b345da1befd242
granularity: file
---
```xml
<mappingExceptions pattern="Definition" resource="TestPlan"
    xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:noNamespaceSchemaLocation="../../tools/schema/mappingExceptions.xsd">
    <!--For information on the contents of this file and how to properly update it, see https://confluence.hl7.org/display/FHIR/Mapping+to+Patterns.-->
    <divergentElement patternPath="Definition.url" resourcePath="TestPlan.url">
        <shortUnmatched reason="Unknown">
            <_pattern value="Canonical identifier for this test plan, represented as an absolute URI (globally unique)"/>
            <resource value="Canonical identifier for this test plan, represented as a URI (globally unique)"/>
        </shortUnmatched>
        <commentsUnmatched reason="Unknown">
            <_pattern value="Can be a `urn:uuid:` or a `urn:oid:` but real `http/s:` addresses are preferred.  Multiple instances may share the same URL if they have a distinct version.&#xa;&#xa;The determination of when to create a new version of a resource (same url, new version) vs. defining a new artifact is up to the author.  Considerations for making this decision are found in [Technical and Business Versions](resource.html#versions).&#xa;&#xa;In some cases, the resource can no longer be found at the stated url, but the url itself cannot change. Implementations can use the [meta.source](resource.html#meta) element to indicate where the current master source of the resource can be found."/>
            <resource value="Can be a urn:uuid: or a urn:oid: but real http: addresses are preferred.  Multiple instances may share the same URL if they have a distinct version.&#xa;&#xa;The determination of when to create a new version of a resource (same url, new version) vs. defining a new artifact is up to the author.  Considerations for making this decision are found in [Technical and Business Versions](resource.html#versions). &#xa;&#xa;In some cases, the resource can no longer be found at the stated url, but the url itself cannot change. Implementations can use the [meta.source](resource.html#meta) element to indicate where the current master source of the resource can be found."/>
        </commentsUnmatched>
    </divergentElement>
    <divergentElement patternPath="Definition.identifier" resourcePath="TestPlan.identifier">
        <shortUnmatched reason="Unknown">
            <_pattern value="Business identifier for test plan"/>
            <resource value="Business identifier identifier for the test plan"/>
        </shortUnmatched>
        <requirementsUnmatched reason="Unknown">
            <_pattern value="Allows externally provided and/or usable business identifiers to be easily associated with the test plan."/>
            <resource value="Allows externally provided and/or usable business identifiers to be easily associated with the module."/>
        </requirementsUnmatched>
    </divergentElement>
    <divergentElement patternPath="Definition.version" resourcePath="TestPlan.version">
        <definitionUnmatched reason="Unknown">
            <_pattern value="The identifier that is used to identify this version of the test plan when it is referenced in a specification, model, design or instance. This is an arbitrary value managed by the test plan author and is not expected to be globally unique. For example, it might be a timestamp (e.g. yyyymmdd) if a managed version is not available. There is also no expectation that versions can be placed in a lexicographical sequence."/>
            <resource value="The identifier that is used to identify this version of the test plan when it is referenced in a specification, model, design or instance.  This is an arbitrary value managed by the test plan author and is not expected to be globally unique. For example, it might be a timestamp (e.g. yyyymmdd) if a managed version is not available. There is also no expectation that versions can be placed in a lexicographical sequence."/>
        </definitionUnmatched>
        <commentsUnmatched reason="Unknown">
            <_pattern value="There may be different test plans that have the same url but different versions.  The version can be appended to the url in a reference to allow a reference to a particular business version of the test plan with the format. The version SHOULD NOT contain a '#' - see [Business Version](resource.html#bv-format)."/>
            <resource value="There may be different test plan instances that have the same identifier but different versions.  The version can be appended to the url in a reference to allow a reference to a particular business version of the test plan with the format [url]|[version]. The version SHOULD NOT contain a '#' - see [Business Version](resource.html#bv-format)."/>
        </commentsUnmatched>
    </divergentElement>
    <divergentElement patternPath="Definition.name" resourcePath="TestPlan.name">
        <commentsUnmatched reason="Unknown">
            <_pattern value="The name is not expected to be globally unique. The name should be a simple alphanumeric type no-whitespace name to ensure that it is machine-processing friendly."/>
            <resource value="The name is not expected to be globally unique. The name should be a simple alphanumeric type name to ensure that it is machine-processing friendly."/>
        </commentsUnmatched>
        <requirementsUnmatched reason="Unknown">
            <_pattern value="Supports code generation."/>
            <resource value="Support code generation."/>
        </requirementsUnmatched>
    </divergentElement>
    <divergentElement patternPath="Definition.title" resourcePath="TestPlan.title">
        <summary _pattern="true" _resource="false" reason="Unknown"/>
    </divergentElement>
    <divergentElement patternPath="Definition.status" resourcePath="TestPlan.status">
        <definitionUnmatched reason="Unknown">
            <_pattern value="The current state of this test plan."/>
            <resource value="The status of this test plan. Enables tracking the life-cycle of the content."/>
        </definitionUnmatched>
        <commentsUnmatched reason="Unknown">
            <_pattern value="A nominal state-transition diagram can be found in the] documentation&#xa;&#xa;Unknown does not represent 'other' - one of the defined statuses must apply.  Unknown is used when the authoring system is not sure what the current status is."/>
            <resource value="Allows filtering of test plans that are appropriate for use versus not.&#xa;&#xa;See guidance around (not) making local changes to elements [here](canonicalresource.html#localization)."/>
        </commentsUnmatched>
        <requirementsUnmatched reason="Unknown">
            <_pattern value="Enables tracking the lifecycle of the content and filtering of test plans that are appropriate for use versus not."/>
            <resource value=""/>
        </requirementsUnmatched>
    </divergentElement>
    <divergentElement patternPath="Definition.experimental" resourcePath="TestPlan.experimental">
        <definitionUnmatched reason="Unknown">
            <_pattern value="A Boolean value to indicate that this test plan is authored for testing purposes (or education/evaluation/marketing) and is not intended for genuine usage."/>
            <resource value="A Boolean value to indicate that this test plan is authored for testing purposes (or education/evaluation/marketing) and is not intended to be used for genuine usage."/>
        </definitionUnmatched>
    </divergentElement>
    <divergentElement patternPath="Definition.date" resourcePath="TestPlan.date">
        <definitionUnmatched reason="Unknown">
            <_pattern value="The date  (and optionally time) when the test plan was last significantly changed. The date must change when the business version changes and it must change if the status code changes. In addition, it should change when the substantive content of the test plan changes."/>
            <resource value="The date (and optionally time) when the test plan was last significantly changed. The date must change when the business version changes and it must change if the status code changes. In addition, it should change when the substantive content of the test plan changes."/>
        </definitionUnmatched>
    </divergentElement>
    <divergentElement patternPath="Definition.description" resourcePath="TestPlan.description">
        <summary _pattern="true" _resource="false" reason="Unknown"/>
        <commentsUnmatched reason="Unknown">
            <_pattern value="This description can be used to capture details such as comments about misuse, instructions for clinical use and interpretation, literature references, examples from the paper world, etc. It is not a rendering of the test plan as conveyed in the 'text' field of the resource itself. This item SHOULD be populated unless the information is available from context."/>
            <resource value="This description can be used to capture details such as comments about misuse, instructions for clinical use and interpretation, literature references, examples from the paper world, etc. It is not a rendering of the test plan as conveyed in the 'text' field of the resource itself. This item SHOULD be populated unless the information is available from context (e.g. the language of the test plan is presumed to be the predominant language in the place the test plan was created)."/>
        </commentsUnmatched>
    </divergentElement>
    <divergentElement patternPath="Definition.useContext" resourcePath="TestPlan.useContext">
        <definitionUnmatched reason="Unknown">
            <_pattern value="The content was developed with a focus and intent of supporting the contexts that are listed. These contexts may be general categories (gender, age, ...) or may be references to specific programs (insurance plans, studies, ...) and may be used to assist with indexing and searching for appropriate test plans."/>
            <resource value="The content was developed with a focus and intent of supporting the contexts that are listed. These contexts may be general categories (gender, age, ...) or may be references to specific programs (insurance plans, studies, ...) and may be used to assist with indexing and searching for appropriate test plan instances."/>
        </definitionUnmatched>
        <commentsUnmatched reason="Unknown">
            <_pattern value="When multiple useContexts are specified, there is no expectation that all or even any of the contexts apply."/>
            <resource value="When multiple useContexts are specified, there is no expectation that all or any of the contexts apply."/>
        </commentsUnmatched>
    </divergentElement>
    <divergentElement patternPath="Definition.jurisdiction" resourcePath="TestPlan.jurisdiction">
        <shortUnmatched reason="Unknown">
            <_pattern value="Intended jurisdiction for test plan (if applicable)"/>
            <resource value="Intended jurisdiction where the test plan applies (if applicable)"/>
        </shortUnmatched>
        <commentsUnmatched reason="Unknown">
            <_pattern value="It may be possible for the test plan to be used in jurisdictions other than those for which it was originally designed or intended&#xa;&#xa;DEPRECATION NOTE: For consistency, implementations are encouraged to migrate to using the new 'jurisdiction' code in the useContext element.  (I.e. useContext.code indicating http://terminology.hl7.org/CodeSystem/usage-context-type#jurisdiction and useContext.valueCodeableConcept indicating the jurisdiction.)."/>
            <resource value="It may be possible for the test plan to be used in jurisdictions other than those for which it was originally designed or intended.&#xa;&#xa;DEPRECATION NOTE: For consistency, implementations are encouraged to migrate to using the new 'jurisdiction' code in the useContext element.  (I.e. useContext.code indicating http://terminology.hl7.org/CodeSystem/usage-context-type#jurisdiction and useContext.valueCodeableConcept indicating the jurisdiction.)"/>
        </commentsUnmatched>
    </divergentElement>
    <divergentElement patternPath="Definition.purpose" resourcePath="TestPlan.purpose">
        <commentsUnmatched reason="Unknown">
            <_pattern value="This element does not describe the usage of the test plan. Instead, it provides traceability of ''why'' the resource is either needed or ''why'' it is defined as it is.  This may be used to point to source materials or specifications that drove the structure of this test plan."/>
            <resource value="This element does not describe the usage of the test plan Instead, it provides traceability of ''why'' the resource is either needed or ''why'' it is defined as it is.  This may be used to point to source materials or specifications that drove the structure of this test plan."/>
        </commentsUnmatched>
    </divergentElement>
    <divergentElement patternPath="Definition.copyright" resourcePath="TestPlan.copyright">
        <requirementsUnmatched reason="Unknown">
            <_pattern value="Consumers of the test plan must be able to determine any legal restrictions on the use of the artifact and/or its content."/>
            <resource value="Consumers must be able to determine any legal restrictions on the use of the test plan and/or its content."/>
        </requirementsUnmatched>
    </divergentElement>
    <unmappedElement patternPath="Definition.derivedFromCanonical" reason="Unknown"/>
    <unmappedElement patternPath="Definition.approvalDate" reason="Unknown"/>
    <unmappedElement patternPath="Definition.copyrightLabel" reason="Unknown"/>
    <unmappedElement patternPath="Definition.effectivePeriod" reason="Unknown"/>
    <unmappedElement patternPath="Definition.product" reason="Unknown"/>
    <unmappedElement patternPath="Definition.code" reason="Unknown"/>
    <unmappedElement patternPath="Definition.lastReviewDate" reason="Unknown"/>
    <unmappedElement patternPath="Definition.subject" reason="Unknown"/>
    <unmappedElement patternPath="Definition.derivedFromUri" reason="Unknown"/>
    <unmappedElement patternPath="Definition.versionAlgorithm" reason="Unknown"/>
    <unmappedElement patternPath="Definition.performerType" reason="Unknown"/>
    <unmappedElement patternPath="Definition.partOf" reason="Unknown"/>
    <unmappedElement patternPath="Definition.topic" reason="Unknown"/>
</mappingExceptions>
```
