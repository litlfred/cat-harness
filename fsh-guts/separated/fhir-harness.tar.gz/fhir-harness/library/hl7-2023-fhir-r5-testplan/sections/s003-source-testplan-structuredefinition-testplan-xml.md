---
doc_id: hl7-2023-fhir-r5-testplan
doc_title: "FHIR R5 (5.0.0) — TestPlan resource"
section_id: s003-source-testplan-structuredefinition-testplan-xml
section_title: "source/testplan/structuredefinition-TestPlan.xml"
file: "source/testplan/structuredefinition-TestPlan.xml"
lines: 1-763
source_sha256: 73a5de0e898ed164
granularity: file
---
```xml
<?xml version="1.0" encoding="UTF-8"?>
<StructureDefinition xmlns="http://hl7.org/fhir" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://hl7.org/fhir ../../schema/fhir-single.xsd">
	<id value="TestPlan"/>
	<meta>
		<lastUpdated value="2021-01-02T08:58:31.578+11:00"/>
	</meta>
	<extension url="http://hl7.org/fhir/StructureDefinition/structuredefinition-category">
		<valueString value="Clinical.Request &amp;amp; Response"/>
	</extension>
	<extension url="http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status">
		<valueCode value="draft"/>
	</extension>
	<extension url="http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm">
		<valueInteger value="0"/>
	</extension>
	<extension url="http://hl7.org/fhir/StructureDefinition/structuredefinition-security-category">
		<valueCode value="business"/>
	</extension>
	<extension url="http://hl7.org/fhir/StructureDefinition/structuredefinition-wg">
		<valueCode value="fhir"/>
	</extension>
	<extension url="http://hl7.org/fhir/build/StructureDefinition/entered-in-error-status">
		<valueCode value=".status = entered-in-error"/>
	</extension>
	<extension url="http://hl7.org/fhir/build/StructureDefinition/template">
		<valueString value="CanonicalResource"/>
	</extension>
	<url value="http://hl7.org/fhir/StructureDefinition/TestPlan"/>
	<version value="5.0.0"/>
	<name value="TestPlan"/>
	<title value="Test Plan"/>
	<status value="draft"/>
	<date value="2021-01-02T08:58:31+11:00"/>
	<publisher value="Health Level Seven International (FHIR Infrastructure)"/>
	<contact>
		<telecom>
			<system value="url"/>
			<value value="http://hl7.org/fhir"/>
		</telecom>
	</contact>
	<contact>
		<telecom>
			<system value="url"/>
			<value value="http://www.hl7.org/Special/committees/fhiriwg/index.cfm"/>
		</telecom>
	</contact>
	<description value="A plan for executing testing on an artifact or specifications"/>
	<fhirVersion value="5.0.0"/>
	<mapping>
		<identity value="workflow"/>
		<uri value="http://hl7.org/fhir/workflow"/>
		<name value="Workflow Pattern"/>
	</mapping>
	<mapping>
		<identity value="rim"/>
		<uri value="http://hl7.org/v3"/>
		<name value="RIM Mapping"/>
	</mapping>
	<mapping>
		<identity value="w5"/>
		<uri value="http://hl7.org/fhir/fivews"/>
		<name value="FiveWs Pattern Mapping"/>
	</mapping>
	<mapping>
		<identity value="objimpl"/>
		<uri value="http://hl7.org/fhir/object-implementation"/>
		<name value="Object Implementation Information"/>
	</mapping>
	<kind value="resource"/>
	<abstract value="false"/>
	<type value="TestPlan"/>
	<baseDefinition value="http://hl7.org/fhir/StructureDefinition/CanonicalResource"/>
	<derivation value="specialization"/>
	<differential>
		<element id="TestPlan">
			<extension url="http://hl7.org/fhir/build/StructureDefinition/svg">
				<valueCode value="0,0"/>
			</extension>
			<path value="TestPlan"/>
			<short value="Description of intented testing"/>
			<definition value="A plan for executing testing on an artifact or specifications."/>
			<min value="0"/>
			<max value="*"/>
			<constraint>
				<key value="cnl-0"/>
				<severity value="warning"/>
				<human value="Name should be usable as an identifier for the module by machine processing applications such as code generation"/>
				<expression value="name.exists() implies name.matches('^[A-Z]([A-Za-z0-9_]){1,254}$')"/>
				<source value="http://hl7.org/fhir/StructureDefinition/TestPlan"/>
			</constraint>
			<mapping>
				<identity value="workflow"/>
				<map value="Definition"/>
			</mapping>
			<mapping>
				<identity value="rim"/>
				<map value="n/a"/>
			</mapping>
			<mapping>
				<identity value="w5"/>
				<map value="conformance.misc"/>
			</mapping>
		</element>
		<element id="TestPlan.url">
			<path value="TestPlan.url"/>
			<short value="Canonical identifier for this test plan, represented as a URI (globally unique)"/>
			<definition value="An absolute URI that is used to identify this test plan when it is referenced in a specification, model, design or an instance; also called its canonical identifier. This SHOULD be globally unique and SHOULD be a literal address at which an authoritative instance of this test plan is (or will be) published. This URL can be the target of a canonical reference. It SHALL remain the same when the test plan is stored on different servers."/>
			<comment value="Can be a urn:uuid: or a urn:oid: but real http: addresses are preferred.  Multiple instances may share the same URL if they have a distinct version.&#xA;&#xA;The determination of when to create a new version of a resource (same url, new version) vs. defining a new artifact is up to the author.  Considerations for making this decision are found in [Technical and Business Versions](resource.html#versions). &#xA;&#xA;In some cases, the resource can no longer be found at the stated url, but the url itself cannot change. Implementations can use the [meta.source](resource.html#meta) element to indicate where the current master source of the resource can be found."/>
			<requirements value="Allows the test plan to be referenced by a single globally unique identifier."/>
			<alias value="url"/>
			<alias value="authoritative-url"/>
			<alias value="destination"/>
			<alias value="identity"/>
			<min value="0"/>
			<max value="1"/>
			<type>
				<code value="uri"/>
			</type>
			<constraint>
				<key value="cnl-1"/>
				<severity value="warning"/>
				<human value="URL should not contain | or # - these characters make processing canonical references problematic"/>
				<expression value="exists() implies matches('^[^|# ]+$')"/>
				<source value="http://hl7.org/fhir/StructureDefinition/CanonicalResource"/>
			</constraint>
			<isSummary value="true"/>
			<mapping>
				<identity value="workflow"/>
				<map value="Definition.url"/>
			</mapping>
			<mapping>
				<identity value="w5"/>
				<map value="FiveWs.identifier"/>
			</mapping>
		</element>
		<element id="TestPlan.identifier">
			<path value="TestPlan.identifier"/>
			<short value="Business identifier identifier for the test plan"/>
			<definition value="A formal identifier that is used to identify this test plan when it is represented in other formats, or referenced in a specification, model, design or an instance."/>
			<comment value="Typically, this is used for identifiers that can go in an HL7 V3 II (instance identifier) data type, and can then identify this test plan outside of FHIR, where it is not possible to use the logical URI."/>
			<requirements value="Allows externally provided and/or usable business identifiers to be easily associated with the module."/>
			<min value="0"/>
			<max value="*"/>
			<type>
				<code value="Identifier"/>
			</type>
			<isSummary value="true"/>
			<mapping>
				<identity value="workflow"/>
				<map value="Definition.identifier"/>
			</mapping>
			<mapping>
				<identity value="w5"/>
				<map value="FiveWs.identifier"/>
			</mapping>
			<mapping>
				<identity value="objimpl"/>
				<map value="no-gen-base"/>
			</mapping>
		</element>
		<element id="TestPlan.version">
			<path value="TestPlan.version"/>
			<short value="Business version of the test plan"/>
			<definition value="The identifier that is used to identify this version of the test plan when it is referenced in a specification, model, design or instance.  This is an arbitrary value managed by the test plan author and is not expected to be globally unique. For example, it might be a timestamp (e.g. yyyymmdd) if a managed version is not available. There is also no expectation that versions can be placed in a lexicographical sequence."/>
			<comment value="There may be different test plan instances that have the same identifier but different versions.  The version can be appended to the url in a reference to allow a reference to a particular business version of the test plan with the format [url]|[version]. The version SHOULD NOT contain a '#' - see [Business Version](resource.html#bv-format)."/>
			<min value="0"/>
			<max value="1"/>
			<type>
				<code value="string"/>
			</type>
			<isSummary value="true"/>
			<mapping>
				<identity value="workflow"/>
				<map value="Definition.version"/>
			</mapping>
			<mapping>
				<identity value="w5"/>
				<map value="FiveWs.version"/>
			</mapping>
		</element>
				<element id="TestPlan.versionAlgorithm[x]">
			<path value="TestPlan.versionAlgorithm[x]"/>
			<short value="How to compare versions"/>
			<definition value="Indicates the mechanism used to compare versions to determine which is more current."/>
			<comment value="If set as a string, this is a FHIRPath expression that has two additional context variables passed in - %version1 and %version2 and will return a negative number if version1 is newer, a positive number if version2 and a 0 if the version ordering can't be successfully be determined."/>
			<min value="0"/>
			<max value="1"/>
			<type>
				<code value="string"/>
			</type>
			<type>
				<code value="Coding"/>
			</type>
			<isSummary value="true"/>
			<binding>
				<strength value="extensible"/>
				<valueSet value="http://hl7.org/fhir/ValueSet/version-algorithm"/>
			</binding>
		</element>
		<element id="TestPlan.name">
			<path value="TestPlan.name"/>
			<short value="Name for this test plan (computer friendly)"/>
			<definition value="A natural language name identifying the test plan. This name should be usable as an identifier for the module by machine processing applications such as code generation."/>
			<comment value="The name is not expected to be globally unique. The name should be a simple alphanumeric type name to ensure that it is machine-processing friendly."/>
			<requirements value="Support code generation."/>
			<min value="0"/>
			<max value="1"/>
			<type>
				<code value="string"/>
			</type>
			<condition value="cnl-0"/>
			<isSummary value="true"/>
			<mapping>
				<identity value="workflow"/>
				<map value="Definition.name"/>
			</mapping>
		</element>
		<element id="TestPlan.title">
			<extension url="http://hl7.org/fhir/StructureDefinition/elementdefinition-translatable">
				<valueBoolean value="true"/>
			</extension>
			<path value="TestPlan.title"/>
			<short value="Name for this test plan (human friendly)"/>
			<definition value="A short, descriptive, user-friendly title for the test plan."/>
			<comment value="This name does not need to be machine-processing friendly and may contain punctuation, white-space, etc."/>
			<min value="0"/>
			<max value="1"/>
			<type>
				<code value="string"/>
			</type>
			<mapping>
				<identity value="workflow"/>
				<map value="Definition.title"/>
			</mapping>
		</element>
		<element id="TestPlan.status">
			<path value="TestPlan.status"/>
			<short value="draft | active | retired | unknown"/>
			<definition value="The status of this test plan. Enables tracking the life-cycle of the content."/>
			<comment value="Allows filtering of test plans that are appropriate for use versus not.&#xa;&#xa;See guidance around (not) making local changes to elements [here](canonicalresource.html#localization)."/>
			<min value="1"/>
			<max value="1"/>
			<type>
				<code value="code"/>
			</type>
			<isModifier value="true"/>
			<isModifierReason value="This is labeled as &quot;Is Modifier&quot; because applications should not use a retired {{title}} without due consideration"/>
			<isSummary value="true"/>
			<binding>
				<extension url="http://hl7.org/fhir/StructureDefinition/elementdefinition-bindingName">
					<valueString value="PublicationStatus"/>
				</extension>
				<extension url="http://hl7.org/fhir/StructureDefinition/elementdefinition-isCommonBinding">
					<valueBoolean value="true"/>
				</extension>
				<strength value="required"/>
				<description value="The lifecycle status of an artifact."/>
				<valueSet value="http://hl7.org/fhir/ValueSet/publication-status"/>
			</binding>
			<mapping>
				<identity value="workflow"/>
				<map value="Definition.status"/>
			</mapping>
			<mapping>
				<identity value="w5"/>
				<map value="FiveWs.status"/>
			</mapping>
		</element>
				<element id="TestPlan.experimental">
			<path value="TestPlan.experimental"/>
			<short value="For testing purposes, not real usage"/>
			<definition value="A Boolean value to indicate that this test plan is authored for testing purposes (or education/evaluation/marketing) and is not intended to be used for genuine usage."/>
			<comment value="Allows filtering of test plans that are appropriate for use versus not."/>
			<requirements value="Enables experimental content to be developed following the same lifecycle that would be used for a production-level test plan."/>
			<min value="0"/>
			<max value="1"/>
			<type>
				<code value="boolean"/>
			</type>
			<meaningWhenMissing value="If absent, this resource is treated as though it is not experimental."/>
			<isSummary value="true"/>
			<mapping>
				<identity value="workflow"/>
				<map value="Definition.experimental"/>
			</mapping>
			<mapping>
				<identity value="w5"/>
				<map value="FiveWs.class"/>
			</mapping>
		</element>
		<element id="TestPlan.date">
			<path value="TestPlan.date"/>
			<short value="Date last changed"/>
			<definition value="The date (and optionally time) when the test plan was last significantly changed. The date must change when the business version changes and it must change if the status code changes. In addition, it should change when the substantive content of the test plan changes."/>
			<comment value="The date is often not tracked until the resource is published, but may be present on draft content. Note that this is not the same as the resource last-modified-date, since the resource may be a secondary representation of the test plan. Additional specific dates may be added as extensions or be found by consulting Provenances associated with past versions of the resource.&#xa;&#xa;See guidance around (not) making local changes to elements [here](canonicalresource.html#localization)."/>
			<alias value="Revision Date"/>
			<min value="0"/>
			<max value="1"/>
			<type>
				<code value="dateTime"/>
			</type>
			<isSummary value="true"/>
			<mapping>
				<identity value="workflow"/>
				<map value="Definition.date"/>
			</mapping>
			<mapping>
				<identity value="w5"/>
				<map value="FiveWs.recorded"/>
			</mapping>
		</element>
		<element id="TestPlan.publisher">
			<extension url="http://hl7.org/fhir/StructureDefinition/elementdefinition-translatable">
				<valueBoolean value="true"/>
			</extension>
			<path value="TestPlan.publisher"/>
			<short value="Name of the publisher/steward (organization or individual)"/>
			<definition value="The name of the organization or individual responsible for the release and ongoing maintenance of the test plan."/>
			<comment value="Usually an organization but may be an individual. The publisher (or steward) of the test plan is the organization or individual primarily responsible for the maintenance and upkeep of the test plan. This is not necessarily the same individual or organization that developed and initially authored the content. The publisher is the primary point of contact for questions or issues with the test plan. This item SHOULD be populated unless the information is available from context."/>
			<requirements value="Helps establish the &quot;authority/credibility&quot; of the test plan.  May also allow for contact."/>
			<min value="0"/>
			<max value="1"/>
			<type>
				<code value="string"/>
			</type>
			<isSummary value="true"/>
			<mapping>
				<identity value="workflow"/>
				<map value="Definition.publisher"/>
			</mapping>
			<mapping>
				<identity value="w5"/>
				<map value="FiveWs.witness"/>
			</mapping>
		</element>
		<element id="TestPlan.contact">
			<path value="TestPlan.contact"/>
			<short value="Contact details for the publisher"/>
			<definition value="Contact details to assist a user in finding and communicating with the publisher."/>
			<comment value="May be a web site, an email address, a telephone number, etc.&#xa;&#xa;See guidance around (not) making local changes to elements [here](canonicalresource.html#localization)."/>
			<min value="0"/>
			<max value="*"/>
			<type>
				<code value="ContactDetail"/>
			</type>
			<isSummary value="true"/>
			<mapping>
				<identity value="workflow"/>
				<map value="Definition.contact"/>
			</mapping>
		</element>
		<element id="TestPlan.description">
			<extension url="http://hl7.org/fhir/StructureDefinition/elementdefinition-translatable">
				<valueBoolean value="true"/>
			</extension>
			<path value="TestPlan.description"/>
			<short value="Natural language description of the test plan"/>
			<definition value="A free text natural language description of the test plan from a consumer's perspective."/>
			<comment value="This description can be used to capture details such as comments about misuse, instructions for clinical use and interpretation, literature references, examples from the paper world, etc. It is not a rendering of the test plan as conveyed in the 'text' field of the resource itself. This item SHOULD be populated unless the information is available from context (e.g. the language of the test plan is presumed to be the predominant language in the place the test plan was created)."/>
			<min value="0"/>
			<max value="1"/>
			<type>
				<code value="markdown"/>
			</type>
			<mapping>
				<identity value="workflow"/>
				<map value="Definition.description"/>
			</mapping>
		</element>
		<element id="TestPlan.useContext">
			<path value="TestPlan.useContext"/>
			<short value="The context that the content is intended to support"/>
			<definition value="The content was developed with a focus and intent of supporting the contexts that are listed. These contexts may be general categories (gender, age, ...) or may be references to specific programs (insurance plans, studies, ...) and may be used to assist with indexing and searching for appropriate test plan instances."/>
			<comment value="When multiple useContexts are specified, there is no expectation that all or any of the contexts apply."/>
			<requirements value="Assist in searching for appropriate content."/>
			<min value="0"/>
			<max value="*"/>
			<type>
				<code value="UsageContext"/>
			</type>
			<isSummary value="true"/>
			<mapping>
				<identity value="workflow"/>
				<map value="Definition.useContext"/>
			</mapping>
		</element>
		<element id="TestPlan.jurisdiction">
			<extension url="http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status">
				<valueCode value="deprecated"/>
			</extension>
			<path value="TestPlan.jurisdiction"/>
			<short value="Intended jurisdiction where the test plan applies (if applicable)"/>
			<definition value="A legal or geographic region in which the test plan is intended to be used."/>
			<comment value="It may be possible for the test plan to be used in jurisdictions other than those for which it was originally designed or intended.&#xa;&#xa;DEPRECATION NOTE: For consistency, implementations are encouraged to migrate to using the new 'jurisdiction' code in the useContext element.  (I.e. useContext.code indicating http://terminology.hl7.org/CodeSystem/usage-context-type#jurisdiction and useContext.valueCodeableConcept indicating the jurisdiction.)"/>
			<min value="0"/>
			<max value="*"/>
			<type>
				<code value="CodeableConcept"/>
			</type>
			<isSummary value="true"/>
			<binding>
				<extension url="http://hl7.org/fhir/StructureDefinition/elementdefinition-bindingName">
					<valueString value="Jurisdiction"/>
				</extension>
				<extension url="http://hl7.org/fhir/StructureDefinition/elementdefinition-isCommonBinding">
					<valueBoolean value="true"/>
				</extension>
				<strength value="extensible"/>
				<description value="Countries and regions within which this artifact is targeted for use."/>
				<valueSet value="http://hl7.org/fhir/ValueSet/jurisdiction"/>
			</binding>
			<mapping>
				<identity value="workflow"/>
				<map value="Definition.jurisdiction"/>
			</mapping>
		</element>
		<element id="TestPlan.purpose">
			<extension url="http://hl7.org/fhir/StructureDefinition/elementdefinition-translatable">
				<valueBoolean value="true"/>
			</extension>
			<path value="TestPlan.purpose"/>
			<short value="Why this test plan is defined"/>
			<definition value="Explanation of why this test plan is needed and why it has been designed as it has."/>
			<comment value="This element does not describe the usage of the test plan Instead, it provides traceability of ''why'' the resource is either needed or ''why'' it is defined as it is.  This may be used to point to source materials or specifications that drove the structure of this test plan."/>
			<min value="0"/>
			<max value="1"/>
			<type>
				<code value="markdown"/>
			</type>
			<mapping>
				<identity value="workflow"/>
				<map value="Definition.purpose"/>
			</mapping>
			<mapping>
				<identity value="w5"/>
				<map value="FiveWs.why[x]"/>
			</mapping>
			<mapping>
				<identity value="objimpl"/>
				<map value="no-gen-base"/>
			</mapping>
		</element>
		<element id="TestPlan.copyright">
			<extension url="http://hl7.org/fhir/StructureDefinition/elementdefinition-translatable">
				<valueBoolean value="true"/>
			</extension>
			<path value="TestPlan.copyright"/>
			<short value="Use and/or publishing restrictions"/>
			<definition value="A copyright statement relating to the test plan and/or its contents. Copyright statements are generally legal restrictions on the use and publishing of the test plan. The short copyright declaration (e.g. (c) '2015+ xyz organization' should be sent in the copyrightLabel element."/> 
			<requirements value="Consumers must be able to determine any legal restrictions on the use of the test plan and/or its content."/>
			<alias value="License"/>
			<alias value="Restrictions"/>
			<min value="0"/>
			<max value="1"/>
			<type>
				<code value="markdown"/>
			</type>
			<mapping>
				<identity value="workflow"/>
				<map value="Definition.copyright"/>
			</mapping>
			<mapping>
				<identity value="objimpl"/>
				<map value="no-gen-base"/>
			</mapping>
		</element>
		<element id="TestPlan.copyrightLabel">
			<extension url="http://hl7.org/fhir/StructureDefinition/elementdefinition-translatable">
				<valueBoolean value="true"/>
			</extension>
			<path value="TestPlan.copyrightLabel"/>
			<short value="Copyright holder and year(s)"/>
			<definition value="A short string (&lt;50 characters), suitable for inclusion in a page footer that identifies the copyright holder, effective period, and optionally whether rights are resctricted. (e.g. 'All rights reserved', 'Some rights reserved')."/>
			<comment value="The (c) symbol should NOT be included in this string. It will be added by software when rendering the notation. Full details about licensing, restrictions, warrantees, etc. goes in the more general 'copyright' element."/>
			<requirements value="Defines the content expected to be rendered in all representations of the artifact."/>
			<min value="0"/>
			<max value="1"/>
			<type>
				<code value="string"/>
			</type>
		</element>
		<element id="TestPlan.category">
			<path value="TestPlan.category"/>
			<short value="The category of the Test Plan - can be acceptance, unit, performance"/>
			<definition value="The category of the Test Plan - can be acceptance, unit, performance, etc."/>
			<min value="0"/>
			<max value="*"/>
			<type>
				<code value="CodeableConcept"/>
			</type>
			<binding>
				<extension url="http://hl7.org/fhir/StructureDefinition/elementdefinition-bindingName">
					<valueString value="TestPlanCategory"/>
				</extension>
				<extension url="http://hl7.org/fhir/tools/StructureDefinition/binding-definition">
					<valueString value="The high-level category for this plan."/>
				</extension>
				<strength value="example"/>
				<description value="The high-level category for this plan."/>
				<valueSet value="http://hl7.org/fhir/ValueSet/testscript-scope-phase-codes"/>
			</binding>
		</element>
		<element id="TestPlan.scope">
			<path value="TestPlan.scope"/>
			<short value="What is being tested with this Test Plan - a conformance resource, or narrative criteria, or an external reference"/>
			<definition value="What is being tested with this Test Plan - a conformance resource, or narrative criteria, or an external reference..."/>
			<min value="0"/>
			<max value="*"/>
			<type>
				<code value="Reference"/>
			</type>
		</element>
		<element id="TestPlan.testTools">
			<path value="TestPlan.testTools"/>
			<short value="A description of test tools to be used in the test plan - narrative for now"/>
			<definition value="A description of test tools to be used in the test plan."/>
			<min value="0"/>
			<max value="1"/>
			<type>
				<code value="markdown"/>
			</type>
		</element>
		<element id="TestPlan.dependency">
			<path value="TestPlan.dependency"/>
			<short value="The required criteria to execute the test plan - e.g. preconditions, previous tests"/>
			<definition value="The required criteria to execute the test plan - e.g. preconditions, previous tests..."/>
			<min value="0"/>
			<max value="*"/>
			<type>
				<code value="BackboneElement"/>
			</type>
		</element>
		<element id="TestPlan.dependency.description">
			<path value="TestPlan.dependency.description"/>
			<short value="Description of the dependency criterium"/>
			<definition value="A textual description of the criterium - what is needed for the dependency to be considered met."/>
			<min value="0"/>
			<max value="1"/>
			<type>
				<code value="markdown"/>
			</type>
		</element>
		<element id="TestPlan.dependency.predecessor">
			<path value="TestPlan.dependency.predecessor"/>
			<short value="Link to predecessor test plans"/>
			<definition value="Predecessor test plans - those that are expected to be successfully performed as a dependency for the execution of this test plan."/>
			<min value="0"/>
			<max value="1"/>
			<type>
				<code value="Reference"/>
			</type>
		</element>
		<element id="TestPlan.exitCriteria">
			<path value="TestPlan.exitCriteria"/>
			<short value="The threshold or criteria for the test plan to be considered successfully executed - narrative"/>
			<definition value="The threshold or criteria for the test plan to be considered successfully executed - narrative."/>
			<min value="0"/>
			<max value="1"/>
			<type>
				<code value="markdown"/>
			</type>
		</element>
		<element id="TestPlan.testCase">
			<path value="TestPlan.testCase"/>
			<short value="The test cases that constitute this plan"/>
			<definition value="The individual test cases that are part of this plan, when they they are made explicit."/>
			<min value="0"/>
			<max value="*"/>
			<type>
				<code value="BackboneElement"/>
			</type>
		</element>
		<element id="TestPlan.testCase.sequence">
			<path value="TestPlan.testCase.sequence"/>
			<short value="Sequence of test case in the test plan"/>
			<definition value="Sequence of test case - an ordinal number that indicates the order for the present test case in the test plan."/>
			<min value="0"/>
			<max value="1"/>
			<type>
				<code value="integer"/>
			</type>
		</element>
		<element id="TestPlan.testCase.scope">
			<path value="TestPlan.testCase.scope"/>
			<short value="The scope or artifact covered by the case"/>
			<definition value="The scope or artifact covered by the case, when the individual test case is associated with a testable artifact."/>
			<min value="0"/>
			<max value="*"/>
			<type>
				<code value="Reference"/>
			</type>
		</element>
		<element id="TestPlan.testCase.dependency">
			<extension url="http://hl7.org/fhir/StructureDefinition/structuredefinition-explicit-type-name">
				<valueString value="TestCaseDependency"/>
			</extension>
			<path value="TestPlan.testCase.dependency"/>
			<short value="Required criteria to execute the test case"/>
			<definition value="The required criteria to execute the test case - e.g. preconditions, previous tests."/>
			<min value="0"/>
			<max value="*"/>
			<type>
				<code value="BackboneElement"/>
			</type>
		</element>
		<element id="TestPlan.testCase.dependency.description">
			<path value="TestPlan.testCase.dependency.description"/>
			<short value="Description of the criteria"/>
			<definition value="Description of the criteria."/>
			<min value="0"/>
			<max value="1"/>
			<type>
				<code value="markdown"/>
			</type>
		</element>
		<element id="TestPlan.testCase.dependency.predecessor">
			<path value="TestPlan.testCase.dependency.predecessor"/>
			<short value="Link to predecessor test plans"/>
			<definition value="Link to predecessor test plans."/>
			<min value="0"/>
			<max value="1"/>
			<type>
				<code value="Reference"/>
			</type>
		</element>
		<element id="TestPlan.testCase.testRun">
			<path value="TestPlan.testCase.testRun"/>
			<short value="The actual test to be executed"/>
			<definition value="The actual test to be executed."/>
			<min value="0"/>
			<max value="*"/>
			<type>
				<code value="BackboneElement"/>
			</type>
		</element>
		<element id="TestPlan.testCase.testRun.narrative">
			<path value="TestPlan.testCase.testRun.narrative"/>
			<short value="The narrative description of the tests"/>
			<definition value="The narrative description of the tests."/>
			<min value="0"/>
			<max value="1"/>
			<type>
				<code value="markdown"/>
			</type>
		</element>
		<element id="TestPlan.testCase.testRun.script">
			<path value="TestPlan.testCase.testRun.script"/>
			<short value="The test cases in a structured language e.g. gherkin, Postman, or FHIR TestScript"/>
			<definition value="The test cases in a structured language e.g. gherkin, Postman, or FHIR TestScript."/>
			<min value="0"/>
			<max value="1"/>
			<type>
				<code value="BackboneElement"/>
			</type>
		</element>
		<element id="TestPlan.testCase.testRun.script.language">
			<path value="TestPlan.testCase.testRun.script.language"/>
			<short value="The language for the test cases e.g. 'gherkin', 'testscript'"/>
			<definition value="The language for the test cases e.g. 'gherkin', 'testscript'."/>
			<min value="0"/>
			<max value="1"/>
			<type>
				<code value="CodeableConcept"/>
			</type>
		</element>
		<element id="TestPlan.testCase.testRun.script.source[x]">
			<path value="TestPlan.testCase.testRun.script.source[x]"/>
			<short value="The actual content of the cases - references to TestScripts or externally defined content"/>
			<definition value="The actual content of the cases - references to TestScripts or externally defined content."/>
			<min value="0"/>
			<max value="1"/>
			<type>
				<code value="string"/>
			</type>
			<type>
				<code value="Reference"/>
			</type>
		</element>
		<element id="TestPlan.testCase.testData">
			<path value="TestPlan.testCase.testData"/>
			<short value="The test data used in the test case"/>
			<definition value="The test data used in the test case."/>
			<min value="0"/>
			<max value="*"/>
			<type>
				<code value="BackboneElement"/>
			</type>
		</element>
		<element id="TestPlan.testCase.testData.type">
			<path value="TestPlan.testCase.testData.type"/>
			<short value="The type of test data description, e.g. 'synthea'"/>
			<definition value="The type of test data description, e.g. 'synthea'."/>
			<min value="1"/>
			<max value="1"/>
			<type>
				<code value="Coding"/>
			</type>
		</element>
		<element id="TestPlan.testCase.testData.content">
			<path value="TestPlan.testCase.testData.content"/>
			<short value="The actual test resources when they exist"/>
			<definition value="The actual test resources when they exist."/>
			<min value="0"/>
			<max value="1"/>
			<type>
				<code value="Reference"/>
			</type>
		</element>
		<element id="TestPlan.testCase.testData.source[x]">
			<path value="TestPlan.testCase.testData.source[x]"/>
			<short value="Pointer to a definition of test resources - narrative or structured e.g. synthetic data generation, etc"/>
			<definition value="Pointer to a definition of test resources - narrative or structured e.g. synthetic data generation, etc."/>
			<min value="0"/>
			<max value="1"/>
			<type>
				<code value="string"/>
			</type>
			<type>
				<code value="Reference"/>
			</type>
		</element>
		<element id="TestPlan.testCase.assertion">
			<path value="TestPlan.testCase.assertion"/>
			<short value="Test assertions or expectations"/>
			<definition value="The test assertions - the expectations of test results from the execution of the test case."/>
			<min value="0"/>
			<max value="*"/>
			<type>
				<code value="BackboneElement"/>
			</type>
		</element>
		<element id="TestPlan.testCase.assertion.type">
			<path value="TestPlan.testCase.assertion.type"/>
			<short value="Assertion type - for example 'informative' or 'required' "/>
			<definition value="The test assertion type - this can be used to group assertions as 'required' or 'optional', or can be used for other classification of the assertion."/>
			<min value="0"/>
			<max value="*"/>
			<type>
				<code value="CodeableConcept"/>
			</type>
		</element>
		<element id="TestPlan.testCase.assertion.object">
			<path value="TestPlan.testCase.assertion.object"/>
			<short value="The focus or object of the assertion"/>
			<definition value="The focus or object of the assertion i.e. a resource."/>
			<min value="0"/>
			<max value="*"/>
			<type>
				<code value="CodeableReference"/>
			</type>
		</element>
		<element id="TestPlan.testCase.assertion.result">
			<path value="TestPlan.testCase.assertion.result"/>
			<short value="The actual result assertion"/>
			<definition value="The test assertion - the expected outcome from the test case execution."/>
			<min value="0"/>
			<max value="*"/>
			<type>
				<code value="CodeableReference"/>
			</type>
		</element>
	</differential>
</StructureDefinition>
```
