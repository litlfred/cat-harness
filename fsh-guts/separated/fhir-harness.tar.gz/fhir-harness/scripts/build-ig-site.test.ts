/**
 * One IG → one just-the-docs Jekyll source with `site.data.fhir` (bean
 * `bamf`). Driven by a synthetic IG, so it names no real one.
 */

import { afterAll, beforeAll, describe, expect, test } from "bun:test";
import { existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { spawnSync } from "node:child_process";
import { join } from "node:path";
import { ARTIFACT_LIST_TEMPLATE_PATH, artifactListInclude, publisherPlural, FOOTER_TEMPLATE_PATH, ARTIFACTS_TEMPLATE_PATH,IG_FIGURE_IMAGES_STAMP, artifactVariables, colourScheme, composeIgSite, contrast, dedupeIds, igTocNav, igTopBar, includeTargets, pageNav, relinkArtifacts, relinkOffSite, rubyLiquidStrings, relinkPublisherOutputs, sourceHeadings, RELEASES_TEMPLATE_PATH, releaseVariables, sizeLabel, stageIgSite, tocPage, type StageResult } from "./build-ig-site";
import { copyDocsInto, igSiteDocs, webpagePalette } from "./stage-ig-sites";
import type { IgReleases } from "../schemas/ig-releases.ts";
import { artifactPageName } from "../schemas/fhir-artifact-index.js";

let dir: string;
let out: string;
let r: StageResult;

beforeAll(() => {
  dir = mkdtempSync(join(tmpdir(), "ig-site-"));
  const src = join(dir, "src");
  for (const d of ["input/pagecontent", "input/includes", "input/images", "input/images-source"]) mkdirSync(join(src, d), { recursive: true });
  writeFileSync(
    join(src, "sushi-config.yaml"),
    [
      "id: example.ig",
      "canonical: http://example.org/ig",
      "name: ExampleIG",
      "title: Example IG",
      "status: draft",
      "version: 0.1.0",
      "fhirVersion: 4.0.1",
      "publisher:",
      "  name: Example Org",
      "pages:",
      "  index.md:",
      "    title: Home",
      "    overview.md:",
      "      title: Overview",
      "  changes.md:",
      "    title: Change Log",
      "",
    ].join("\n"),
  );
  const pc = join(src, "input", "pagecontent");
  writeFileSync(join(pc, "index.md"), "Package {{ site.data.fhir.packageId }}.\n{% include overview.md %}\n");
  writeFileSync(join(pc, "overview.md"), "{% include flow.svg %}\n{% include notes.md %}\n");
  writeFileSync(join(pc, "changes.md"), "Nothing yet.\n");
  writeFileSync(join(pc, "orphan.md"), "Not in sushi-config.\n");
  writeFileSync(join(src, "input", "includes", "notes.md"), "a note\n");
  writeFileSync(join(src, "input", "images", "logo.png"), "png");
  writeFileSync(join(src, "input", "images", "good.jsonld"), '{"@id": "x"}');
  writeFileSync(join(src, "input", "images", "broken.jsonld"), '{"a: 1}');
  writeFileSync(join(src, "input", "images-source", "flow.plantuml"), "@startuml\nA -> B\n@enduml\n");
  out = join(dir, "site");
  r = stageIgSite(src, out, { baseurl: "/site/example" });
});
afterAll(() => rmSync(dir, { recursive: true, force: true }));

describe("staging one IG as one just-the-docs site", () => {
  test("site.data.fhir is written from sushi-config, only what is sourced", () => {
    const fhir = JSON.parse(readFileSync(join(out, "_data", "fhir.json"), "utf-8"));
    expect(fhir.packageId).toBe("example.ig");
    expect(fhir.ig.version).toBe("0.1.0");
    expect(fhir.ig.publisher).toBe("Example Org");
    expect(JSON.stringify(fhir)).not.toContain('""');
  });

  test("navigation comes from sushi-config pages: titles, parents, order", () => {
    const nav = pageNav({ "index.md": { title: "Home", "overview.md": { title: "Overview" } }, "changes.md": { title: "Change Log" } });
    expect(nav.get("index")).toEqual({ title: "Home", navOrder: 1 });
    expect(nav.get("overview")).toEqual({ title: "Overview", parent: "Home", navOrder: 2 });
    expect(nav.get("changes")).toEqual({ title: "Change Log", navOrder: 3 });
    expect(readFileSync(join(out, "overview.md"), "utf-8")).toStartWith('---\ntitle: "Overview"\nparent: "Home"\nnav_order: 2\nig_footer: true\n');
  });

  test("a page sushi-config does not list is kept, titled by file name, and reported", () => {
    expect(r.unlisted).toEqual(["orphan.md"]);
    expect(readFileSync(join(out, "orphan.md"), "utf-8")).toContain('title: "orphan"');
  });

  test("pages, includes and images land where Jekyll resolves them", () => {
    expect(r.pages).toEqual(["changes.md", "index.md", "orphan.md", "overview.md"]);
    for (const f of ["notes.md", "overview.md", "index.md"]) expect(readFileSync(join(out, "_includes", f), "utf-8").length).toBeGreaterThan(0);
    expect(readFileSync(join(out, "logo.png"), "utf-8")).toBe("png");
  });

  test("a data file that does not parse is not published, and is reported", () => {
    expect(existsSync(join(out, "good.jsonld"))).toBe(true);
    expect(existsSync(join(out, "broken.jsonld"))).toBe(false);
    expect(r.unparseable).toHaveLength(1);
    expect(r.unparseable[0]).toStartWith("broken.jsonld (");
  });

  test("a diagram the Publisher renders, with no renderer given, is a VISIBLE marker and reported", () => {
    expect(r.notRendered).toEqual(["flow.svg"]);
    expect(r.rendered).toEqual([]);
    expect(readFileSync(join(out, "_includes", "flow.svg"), "utf-8")).toContain("⟦not rendered: flow.svg⟧");
  });

  test("the config is one just-the-docs site at the given baseurl", () => {
    const cfg = readFileSync(join(out, "_config.yml"), "utf-8");
    expect(cfg).toContain('title: "Example IG"');
    expect(cfg).toContain('baseurl: "/site/example"');
    expect(cfg).toContain("theme: just-the-docs");
  });

  test("include targets are read from the page, including lang-fragment", () => {
    expect(includeTargets("{% include a.svg %} x {%- include b.md -%} y {% lang-fragment table.xhtml %}")).toEqual(["a.svg", "b.md", "table.xhtml"]);
  });

  test("a repeated id keeps its first copy and the rest are renamed, each reported", () => {
    const r = dedupeIds(`<h3 id="x">a</h3><h3 id="x">b</h3><a id='x'></a><p id="y"></p>`);
    expect(r.html).toBe(`<h3 id="x">a</h3><h3 id="x--2">b</h3><a id='x--3'></a><p id="y"></p>`);
    expect(r.renamed).toEqual(["x -> x--2", "x -> x--3"]);
  });

  test("with no palette there is no scheme, and the report says so", () => {
    expect(r.scheme).toBeUndefined();
    expect(readFileSync(join(out, "_config.yml"), "utf-8")).not.toContain("color_scheme");
  });
});

// A synthetic palette: a dark accent, so the sidebar must take the light role.
const PALETTE = { surface: "#f7f7f7", ink: "#111111", edge: "#dddddd", accent: "#123456" };

describe("the instance's palette as a just-the-docs colour scheme", () => {
  test("WCAG contrast is computed as the spec defines it", () => {
    expect(contrast("#000000", "#ffffff")).toBeCloseTo(21, 5);
    expect(contrast("#fff", "#ffffff")).toBeCloseTo(1, 5);
    expect(contrast("navy", "#ffffff")).toBeUndefined();
  });

  test("each role lands on the scheme variable just-the-docs reads", () => {
    const s = colourScheme(PALETTE).scss;
    expect(s).toContain("$feedback-color: darken($sidebar-color, 3%);");
    expect(s).toContain("$body-background-color: #f7f7f7;");
    expect(s).toContain("$body-text-color: #111111;");
    expect(s).toContain("$link-color: #123456;");
    expect(s).toContain("$border-color: #dddddd;");
    expect(s).toContain("$sidebar-color: #123456;");
  });

  test("sidebar text is the palette role with more contrast on accent, never a literal", () => {
    const dark = colourScheme(PALETTE);
    expect(dark.sidebarText).toBe("surface");
    expect(dark.scss).toContain("$nav-child-link-color: #f7f7f7;");
    const light = colourScheme({ ...PALETTE, accent: "#eeeeaa" });
    expect(light.sidebarText).toBe("ink");
  });

  test("a pairing below AA, or one that cannot be computed, is a finding", () => {
    expect(colourScheme(PALETTE).findings).toEqual([]);
    const low = colourScheme({ ...PALETTE, accent: "#999999" }).findings;
    expect(low.some((f) => f.startsWith("accent on surface (links)"))).toBe(true);
    const named = colourScheme({ ...PALETTE, accent: "navy" }).findings;
    expect(named.some((f) => f.includes("not computable"))).toBe(true);
  });

  test("a staged site with a palette selects the scheme and ships its files", () => {
    const o = join(dir, "themed");
    const t = stageIgSite(join(dir, "src"), o, { palette: PALETTE });
    expect(t.scheme?.sidebarText).toBe("surface");
    expect(readFileSync(join(o, "_config.yml"), "utf-8")).toContain("color_scheme: ig");
    expect(readFileSync(join(o, "_sass", "color_schemes", "ig.scss"), "utf-8")).toContain("$sidebar-color: #123456;");
    expect(readFileSync(join(o, "_sass", "custom", "custom.scss"), "utf-8")).toContain("$nav-child-link-color");
  });
});

describe("pages the Publisher generates, written from data the build holds (bean jut3)", () => {
  test("toc lists every page in the tree, nested, and links only pages that exist", () => {
    const t = tocPage({ "index.md": { title: "Home", "overview.md": { title: "Overview" } }, "artifacts.html": { title: "Artifacts" } }, (s) => s !== "artifacts");
    expect(t).toContain("- [Home](index.html)\n  - [Overview](overview.html)");
    // Not held and not generated: text, never a link to a page that is not there.
    expect(t).toContain("- Artifacts (generated by the IG Publisher; not part of this build)");
    expect(t).not.toContain("](artifacts.html)");
  });

  test("a staged site always gets a toc, reported as generated rather than as a source page", () => {
    expect(r.generated).toContain("toc.md");
    expect(r.pages).not.toContain("toc.md");
    expect(readFileSync(join(out, "toc.md"), "utf-8")).toContain("[Change Log](changes.html)");
  });

  test("the lifted variables keep generate_smart_liquid's families and keys, minus the smart__ prefix", () => {
    const list = [
      { resourceType: "ValueSet", id: "a-b", title: "A [b]", category: "Terminology", canonical: "http://x/ValueSet/a-b", version: "1.0", published: { json: { url: "https://p/ValueSet-a-b.json" }, xml: { url: "https://p/ValueSet-a-b.xml" } } },
      { resourceType: "Endpoint", id: "e", category: undefined },
    ];
    const { vars, notSourced } = artifactVariables(list, "../artifact/");
    // smart__ValueSet__a_b__url__page  ->  site.data.fhir.artifacts.ValueSet__a_b.url.page
    const v = vars.artifacts["ValueSet__a_b"]!;
    expect(v.url.page).toBe(`../artifact/${artifactPageName(list[0]!)}.html`);
    expect(v.url.canonical).toBe("http://x/ValueSet/a-b");
    expect(v.url.json).toBe("https://p/ValueSet-a-b.json");
    expect(v.text.display).toBe("A [b]");
    expect(v.text.label).toBe("A \\[b\\]");
    expect(vars.artifacts_listed).toBe(1);
    expect(v.link.html).toBe('<a href="../artifact/ValueSet-a-b.html">A [b]</a>');
    expect(v.elements).toEqual({ title: "A [b]", version: "1.0" });
    // Uncategorised = not on the Publisher's artifacts.html: variables written, not grouped.
    expect(vars.artifact_categories).toEqual([{ name: "Terminology", anchor: "artifacts-terminology", count: 1, keys: ["ValueSet__a_b"] }]);
    // No description is an empty cell, never "undefined".
    expect(v.text.description_cell).toBe("");
    expect(vars.artifacts["Endpoint__e"]).toBeDefined();
    // What no source holds is REPORTED, never written empty.
    expect(notSourced).toContain("status");
    expect(Object.values(vars.artifacts).every((a) => !("status" in a.elements))).toBe(true);
  });

  const ruby = spawnSync("ruby", ["-e", 'require "liquid"'], { encoding: "utf-8" }).status === 0;
  test.skipIf(!ruby)("the artifacts TEMPLATE renders the variables through real Liquid", () => {
    const { vars } = artifactVariables([{ resourceType: "ValueSet", id: "v", title: "V [x]", category: "Terminology: Value Sets", description: "Codes for a | b,\nover two lines." }], "../artifact/");
    const script = 'require "liquid"; require "json"; d = JSON.parse(STDIN.read.force_encoding("UTF-8")); print Liquid::Template.parse(d["t"], error_mode: :strict).render("site" => { "data" => { "fhir" => d["v"] } })';
    const r = spawnSync("ruby", ["-e", script], { input: JSON.stringify({ t: readFileSync(ARTIFACTS_TEMPLATE_PATH, "utf-8"), v: vars }), encoding: "utf-8" });
    expect(r.stderr).toBe("");
    expect(r.stdout).toContain("1 artefact(s).");
    // #1901: one COLLAPSED section per category, a Name | Description table inside,
    // `markdown="1"` so kramdown renders the table rather than printing pipes.
    expect(r.stdout).toContain('<details markdown="1" id="artifacts-terminology-value-sets">');
    expect(r.stdout).toContain("<summary><strong>Terminology: Value Sets</strong> — 1</summary>");
    expect(r.stdout).not.toContain("<details open");
    expect(r.stdout).toContain("| Name | Description |");
    expect(r.stdout).toContain("| [V \\[x\\]](../artifact/ValueSet-v.html) | Codes for a \\| b, over two lines. |");
  });

  test("the artifacts template is a file that opens with the comment describing it", () => {
    // `liquid-templates`: never an inline template in a .ts, and the leading
    // comment is the file's description; computation stays in the generator.
    const t = readFileSync(ARTIFACTS_TEMPLATE_PATH, "utf-8");
    expect(t.startsWith("{%- comment -%}")).toBe(true);
    expect(t).not.toMatch(/\|\s*(plus|minus|size|replace)\b/);
  });

  test("without an index there is no artifacts page, and the menu still reports it missing", () => {
    expect(existsSync(join(out, "artifacts.md"))).toBe(false);
    expect(r.generated).not.toContain("artifacts.md");
  });
});

describe("post-processing fills: content a step writes after the Publisher, at a marker the source holds", () => {
  test("the marker is replaced, the data reaches the page's front matter, and an unused fill is reported", () => {
    const d = mkdtempSync(join(tmpdir(), "ig-fill-"));
    try {
      const src = join(d, "src");
      mkdirSync(join(src, "input", "pagecontent"), { recursive: true });
      writeFileSync(join(src, "sushi-config.yaml"), "id: x\ncanonical: http://x\nname: X\nversion: 0.1.0\nfhirVersion: 4.0.1\npages:\n  hub.md:\n    title: Hub\n");
      writeFileSync(join(src, "input", "pagecontent", "hub.md"), "# Hub\n\nIntro.\n\n<!-- MARK -->\n");
      const res = stageIgSite(src, join(d, "site"), {
        fills: [
          { marker: "<!-- MARK -->", body: "filled {{ page.k.v }}", data: { k: { v: "y" } } },
          { marker: "<!-- NOWHERE -->", body: "z", data: {} },
        ],
      });
      const page = readFileSync(join(d, "site", "hub.md"), "utf-8");
      expect(page.split("\n---\n")[0]).toContain('\nk: {"v":"y"}\n');
      expect(page).toContain("Intro.\n\nfilled {{ page.k.v }}");
      expect(page).not.toContain("<!-- MARK -->");
      expect(res.fills).toEqual({ filled: ["hub.md (<!-- MARK -->)"], unused: ["<!-- NOWHERE -->"] });
    } finally {
      rmSync(d, { recursive: true, force: true });
    }
  });
});

describe("the releases page: pointers to release binaries, never the bytes (bean b8ip)", () => {
  const releases: IgReleases = {
    $schema: "ig-releases/v1",
    repository: "o/r",
    readAt: "2026-10-02",
    releases: [
      {
        tag: "v1.0.0",
        url: "https://github.com/o/r/releases/tag/v1.0.0",
        publishedAt: "2026-03-23T17:39:19Z",
        prerelease: false,
        assets: [
          { name: "package.tgz", url: "https://github.com/o/r/releases/download/v1.0.0/package.tgz", bytes: 915317, digest: `sha256:${"a".repeat(64)}` },
          { name: "package.db", url: "https://github.com/o/r/releases/download/v1.0.0/package.db", bytes: 13864960 },
        ],
      },
    ],
  };

  test("sizes are labelled as a reader reads them", () => {
    expect(sizeLabel(915317)).toBe("915 KB");
    expect(sizeLabel(13864960)).toBe("13.9 MB");
    expect(sizeLabel(10)).toBe("1 KB");
  });

  test("every value the template shows is computed here", () => {
    const v = releaseVariables(releases);
    expect(v.releases[0]).toMatchObject({ tag: "v1.0.0", name: "v1.0.0", published: "2026-03-23", prerelease: false });
    expect(v.releases[0].assets.map((a) => [a.name, a.size, a.digest])).toEqual([
      ["package.tgz", "915 KB", `sha256:${"a".repeat(64)}`],
      ["package.db", "13.9 MB", null],
    ]);
  });

  test("given releases, the page and its data are written and reported as generated; absent, neither is", () => {
    const d = mkdtempSync(join(tmpdir(), "ig-rel-"));
    try {
      const src = join(d, "src");
      mkdirSync(join(src, "input", "pagecontent"), { recursive: true });
      writeFileSync(join(src, "sushi-config.yaml"), "id: x\ncanonical: http://x\nname: X\nversion: 0.1.0\nfhirVersion: 4.0.1\npages:\n  index.md:\n    title: Home\n");
      writeFileSync(join(src, "input", "pagecontent", "index.md"), "# Home\n");
      const res = stageIgSite(src, join(d, "with"), { releases });
      expect(res.generated).toContain("releases.md");
      expect(readFileSync(join(d, "with", "releases.md"), "utf-8")).toContain(readFileSync(RELEASES_TEMPLATE_PATH, "utf-8"));
      expect(JSON.parse(readFileSync(join(d, "with", "_data", "ig_releases.json"), "utf-8"))).toEqual(releaseVariables(releases));
      const none = stageIgSite(src, join(d, "without"), {});
      expect(none.generated).not.toContain("releases.md");
      expect(existsSync(join(d, "without", "_data", "ig_releases.json"))).toBe(false);
    } finally {
      rmSync(d, { recursive: true, force: true });
    }
  });
});

// Bean `mftp`: the IG's prose links an artefact at the Publisher's flat path;
// this site keeps artefact pages under `pagesHref`.
describe("relinkArtifacts", () => {
  const names = new Set(["ValueSet-Domains", "CodeSystem-Actors"]);
  test("rewrites a markdown link and an href to an artefact page, and nothing else", () => {
    const src = "[d](ValueSet-Domains.html) [a](CodeSystem-Actors.html#x) <a href=\"ValueSet-Domains.html\">v</a> [c](concepts.html) [e](https://x.org/ValueSet-Domains.html) [s](sub/ValueSet-Domains.html)";
    const r = relinkArtifacts(src, names, "artifact/");
    expect(r.count).toBe(3);
    expect(r.text).toBe("[d](artifact/ValueSet-Domains.html) [a](artifact/CodeSystem-Actors.html#x) <a href=\"artifact/ValueSet-Domains.html\">v</a> [c](concepts.html) [e](https://x.org/ValueSet-Domains.html) [s](sub/ValueSet-Domains.html)");
  });
  test("is a no-op when the source links no artefact", () => {
    expect(relinkArtifacts("[c](concepts.html)", names, "../artifact/")).toEqual({ text: "[c](concepts.html)", count: 0 });
  });
});

describe("copyDocsInto (an igSite instance's pages built into its IG site)", () => {
  test("copies every file but the README, and refuses to overwrite one the IG site wrote", () => {
    const d = mkdtempSync(join(tmpdir(), "ig-docs-"));
    const docs = join(d, "docs");
    const site = join(d, "site");
    mkdirSync(join(docs, "artifact"), { recursive: true });
    mkdirSync(site, { recursive: true });
    writeFileSync(join(docs, "README.md"), "repo docs");
    writeFileSync(join(docs, "artifact", "A.md"), "a");
    writeFileSync(join(docs, "artifacts.md"), "mine");
    writeFileSync(join(site, "artifacts.md"), "the IG site's");
    const c = copyDocsInto(docs, site);
    expect(c).toEqual({ copied: 1, merged: [], collisions: ["artifacts.md"] });
    expect(readFileSync(join(site, "artifact", "A.md"), "utf-8")).toBe("a");
    expect(readFileSync(join(site, "artifacts.md"), "utf-8")).toBe("the IG site's");
    expect(existsSync(join(site, "README.md"))).toBe(false);
    rmSync(d, { recursive: true, force: true });
  });
});

describe("copyDocsInto: a front-matter-only page declares something ABOUT a generated page", () => {
  test("its keys land on the generated page's front matter, the page's own keys winning", () => {
    const d = mkdtempSync(join(tmpdir(), "ig-docs-"));
    mkdirSync(join(d, "docs"), { recursive: true });
    mkdirSync(join(d, "site"), { recursive: true });
    writeFileSync(join(d, "docs", "artifacts.md"), "---\ntitle: mine\nrenders:\n  - x/fhir-artifact-index\nrendered-by: ig-pages\n---\n");
    writeFileSync(join(d, "site", "artifacts.md"), "---\ntitle: Artifact Index\nparent: Indices\n---\nbody\n");
    writeFileSync(join(d, "docs", "orphan.md"), "---\nrenders:\n  - y\n---\n");
    const c = copyDocsInto(join(d, "docs"), join(d, "site"));
    expect(c.merged).toEqual(["artifacts.md"]);
    expect(c.collisions).toEqual(["orphan.md (front matter only, and no generated page to lay it on)"]);
    expect(readFileSync(join(d, "site", "artifacts.md"), "utf-8")).toBe("---\ntitle: Artifact Index\nparent: Indices\nrenders:\n  - x/fhir-artifact-index\nrendered-by: ig-pages\n---\nbody\n");
    rmSync(d, { recursive: true, force: true });
  });
});

// Synthetic instances in a temp "repository", so this layer tests the
// mechanism without naming an instance above it. The same two properties over
// the REAL smart-* instances live in `test/build-ig-site-checkout.test.ts`
// (bean `7zz1`): standing alone, fhir-harness has none of them.
//
// `leaf` → `mid` → `base` is the shape smart-trust → smart-ig → smart-base
// has: two hops, the middle one declaring no theme.
const THEME_TS = join(import.meta.dir, "..", "..", "cat-harness", "schemas", "theme.ts");
const BASE_THEME = `import { ResolvedThemeSchema } from ${JSON.stringify(THEME_TS)};
export const INSTANCE_THEMES = [ResolvedThemeSchema.parse({
  $schema: "folio-theme/v1", kind: "webpage", id: "base-web", name: "Base",
  palette: { surface: "#ffffff", ink: "#111111", edge: "#cccccc", accent: "#0066aa" },
  layouts: {
    laptop: { minWidth: "1000px", padding: "1rem", fontScale: 1 },
    mobile: { minWidth: "100%", padding: "1rem", fontScale: 1 },
    card: { minWidth: "200px", padding: "1rem", fontScale: 1 },
  },
})];
`;

let fixtureRoot: string;
beforeAll(() => {
  fixtureRoot = mkdtempSync(join(tmpdir(), "ig-instances-"));
  mkdirSync(join(fixtureRoot, ".git"));
  const instance = (name: string, decl: Record<string, unknown>): string => {
    const at = join(fixtureRoot, name);
    mkdirSync(at, { recursive: true });
    writeFileSync(join(at, `${name}.json`), JSON.stringify({ name, version: "0.1.0", directories: [], ...decl }, null, 2));
    return at;
  };
  const base = instance("base", {
    directories: [
      { id: "base-themes", path: "themes/", graphTypologies: ["themes"] },
      { id: "base-docs", path: "docs/", graphTypologies: ["docs"], igSite: true },
    ],
  });
  mkdirSync(join(base, "themes"), { recursive: true });
  writeFileSync(join(base, "themes", "themes.ts"), BASE_THEME);
  instance("mid", { needs: ["base"] });
  instance("leaf", { needs: ["mid"], directories: [{ id: "leaf-docs", path: "docs/", graphTypologies: ["docs"], igSite: true }] });
  instance("plain", { directories: [{ id: "plain-docs", path: "docs/", graphTypologies: ["docs"] }] });
});
afterAll(() => rmSync(fixtureRoot, { recursive: true, force: true }));

describe("igSiteDocs", () => {
  test("only an instance that DECLARES igSite builds its IG site at its root", () => {
    expect(igSiteDocs(join(fixtureRoot, "leaf"))).toBe(join(fixtureRoot, "leaf", "docs/"));
    expect(igSiteDocs(join(fixtureRoot, "base"))).toBe(join(fixtureRoot, "base", "docs/"));
    // A docs directory that does not declare igSite is not one.
    expect(igSiteDocs(join(fixtureRoot, "plain"))).toBeUndefined();
    // Nor is an instance with no docs directory at all.
    expect(igSiteDocs(join(fixtureRoot, "mid"))).toBeUndefined();
  });
});

describe("webpagePalette inherits along needs (bean `mftp`)", () => {
  test("an instance that declares no theme wears the nearest one along its needs, through one that declares none", () => {
    const t = webpagePalette(fixtureRoot, "leaf");
    expect(t.palette?.accent).toBe("#0066aa");
    expect(t.note).toContain("inherited from base");
    expect(webpagePalette(fixtureRoot, "base").note).not.toContain("inherited");
  });
  test("with no theme anywhere along its needs, there is no palette, and the note says why", () => {
    const t = webpagePalette(fixtureRoot, "plain");
    expect(t.palette).toBeUndefined();
    expect(t.note).toContain("no webpage theme");
  });
});

// Bean `mftp`, owner 2026-10-05: the folio-assistant navbar, not just-the-docs'
// sidebar, and the IG's own top bar preserved.
describe("every IG site: the IG's top bar, and its TOC declared for the navbar", () => {
  const menu = { groups: [{ label: "Home", items: [{ label: "Summary", href: "overview.html" }] }, { label: "Indices", items: [{ label: "Artifact Index", href: "artifacts.html" }, { label: "Spec", href: "https://example.org/x" }] }] };
  test("the TOC is a visualiser declaration the navbar reads, rows under each group, hrefs under the baseurl", () => {
    const decl = igTocNav(menu, "/b/smart-trust", [{ label: "Table of Contents", href: "toc.html" }]);
    expect(decl.startsWith('<script type="application/json" data-fa-visualiser-nav>')).toBe(true);
    const rows = JSON.parse(decl.replace(/^<script[^>]*>/, "").replace(/<\/script>$/, ""));
    expect(rows).toEqual([
      { label: "Home", items: [{ label: "Summary", href: "/b/smart-trust/overview.html" }] },
      { label: "Indices", items: [{ label: "Artifact Index", href: "/b/smart-trust/artifacts.html" }, { label: "Spec", href: "https://example.org/x" }] },
      { label: "Table of Contents", href: "/b/smart-trust/toc.html" },
    ]);
  });
  test("the top bar is one dropdown per group, and never reads as the folio navbar", () => {
    const bar = igTopBar(menu, "/b/smart-trust", "WHO SMART Trust");
    expect(bar).toContain('<summary>Home</summary>');
    expect(bar).toContain('href="/b/smart-trust/overview.html"');
    expect(bar).not.toContain("fa-nav");
    expect(bar).not.toContain('id="site-nav"');
  });
  test("a harness-chrome site has a layout with no sidebar of its own", () => {
    const d = mkdtempSync(join(tmpdir(), "ig-chrome-"));
    const src = join(d, "src");
    mkdirSync(join(src, "input", "pagecontent"), { recursive: true });
    writeFileSync(join(src, "sushi-config.yaml"), "id: x.ig\ntitle: X IG\n");
    writeFileSync(join(src, "input", "pagecontent", "index.md"), "# Hi\n");
    stageIgSite(src, join(d, "out"), { menu, baseurl: "/b/x" });
    const layout = readFileSync(join(d, "out", "_layouts", "default.html"), "utf-8");
    expect(layout).toContain("data-fa-visualiser-nav");
    expect(layout).toContain('class="ig-topbar"');
    expect(layout).not.toContain("site-nav");
    expect(layout).toContain('<meta name="fa-visualiser-label" content="X IG">');
    rmSync(d, { recursive: true, force: true });
  });
});

// #1901, owner 2026-10-02: "footer is missing" — the Publisher's footer, from
// the IG's own metadata, linking only what this site holds.
describe("the Publisher's page footer on the IG site's own pages (#1901)", () => {
  const sushi = [
    "id: x.ig",
    "title: X IG",
    "version: 0.2.0",
    "fhirVersion: 5.0.0",
    "copyrightYear: 2023+",
    "license: CC0-1.0",
    "publisher:",
    "  name: Example Org",
    "  url: https://example.org",
    "pages:",
    "  index.md:",
    "    title: Home",
    "  concepts.md:",
    "    title: Concepts",
    "  missing.md:",
    "    title: Not built",
    "  changes.md:",
    "    title: Changes",
    "",
  ].join("\n");
  const stage = (opts: Parameters<typeof stageIgSite>[2]) => {
    const d = mkdtempSync(join(tmpdir(), "ig-footer-"));
    const src = join(d, "src");
    mkdirSync(join(src, "input", "pagecontent"), { recursive: true });
    writeFileSync(join(src, "sushi-config.yaml"), sushi);
    for (const p of ["index", "concepts", "changes"]) writeFileSync(join(src, "input", "pagecontent", `${p}.md`), `# ${p}\n`);
    stageIgSite(src, join(d, "out"), opts);
    return { d, out: join(d, "out") };
  };
  const menu = { groups: [{ label: "Home", items: [{ label: "Concepts", href: "concepts.html" }] }] };

  test("the facts come from the package first, then the IG's source; links only to what is held", () => {
    const { d, out } = stage({ menu, footer: { facts: { version: "0.2.1", generated: "2026-10-01", packageId: "x.ig" }, scope: "st-ig", stylesheets: ["assets/ig-pages.css"] } });
    const f = JSON.parse(readFileSync(join(out, "_data", "fhir.json"), "utf-8")).footer;
    expect(f).toMatchObject({
      publisher: "Example Org",
      publisherUrl: "https://example.org",
      packageId: "x.ig",
      version: "0.2.1", // the package's, over sushi-config's 0.2.0
      fhirVersion: "5.0.0",
      fhirUrl: "http://hl7.org/fhir/R5/",
      generated: "2026-10-01",
      copyrightYear: "2023+",
      scope: "st-ig",
      stylesheets: ["assets/ig-pages.css"],
    });
    // toc.html is always written; qa.html and history.html are not, so no link.
    expect(f.links).toEqual([
      { label: "Table of Contents", href: "toc.html" },
      { label: "License", href: "https://spdx.org/licenses/CC0-1.0.html", external: true },
    ]);
    rmSync(d, { recursive: true, force: true });
  });

  test("prev and next follow the IG's table-of-contents order, skipping what is not built", () => {
    const { d, out } = stage({ menu });
    const fm = (p: string) => readFileSync(join(out, p), "utf-8").split("\n---")[0]!;
    expect(fm("index.md")).toContain("ig_footer: true");
    expect(fm("index.md")).not.toContain("ig_prev");
    expect(fm("index.md")).toContain('ig_next: "concepts.html"');
    expect(fm("concepts.md")).toContain('ig_prev: "index.html"');
    expect(fm("concepts.md")).toContain('ig_next: "changes.html"'); // missing.md is skipped
    expect(fm("changes.md")).not.toContain("ig_next");
    // A generated page carries the footer, outside the order.
    expect(fm("toc.md")).toContain("ig_footer: true");
    expect(fm("toc.md")).not.toContain("ig_prev");
    // The layout draws it last, only where the page asks.
    const layout = readFileSync(join(out, "_layouts", "default.html"), "utf-8");
    expect(layout).toContain("{% if page.ig_footer %}{% include fa-ig-footer.html %}{% endif %}\n</main>");
    expect(existsSync(join(out, "_includes", "fa-ig-footer.html"))).toBe(true);
    rmSync(d, { recursive: true, force: true });
  });

  test("without a menu there is no generated layout, so the footer goes into the page", () => {
    const { d, out } = stage({});
    expect(readFileSync(join(out, "concepts.md"), "utf-8")).toMatch(/\{% include fa-ig-footer\.html %\}\n$/);
    rmSync(d, { recursive: true, force: true });
  });

  test("composed into a host site, the footer include is namespaced and gated by the page", () => {
    const { d, out } = stage({ menu });
    const host = join(d, "host");
    mkdirSync(host, { recursive: true });
    expect(composeIgSite(out, host, "x").collisions).toEqual([]);
    expect(readFileSync(join(host, "x", "concepts.md"), "utf-8")).toContain("{% include ig/_bottom.html %}\n{% if page.ig_footer %}{% include ig/x/fa-ig-footer.html %}{% endif %}");
    expect(readFileSync(join(host, "_includes", "ig", "x", "fa-ig-footer.html"), "utf-8")).toContain('site.data.ig["x"].fhir.footer');
    rmSync(d, { recursive: true, force: true });
  });

  const ruby = spawnSync("ruby", ["-e", 'require "liquid"'], { encoding: "utf-8" }).status === 0;
  test.skipIf(!ruby)("the footer TEMPLATE renders the Publisher's three rows through real Liquid", () => {
    const footer = {
      publisher: "Example Org", publisherUrl: "https://example.org", packageId: "x.ig", version: "0.2.1",
      fhirVersion: "5.0.0", fhirUrl: "http://hl7.org/fhir/R5/", generated: "2026-10-01", copyrightYear: "2023+",
      links: [{ label: "Table of Contents", href: "toc.html" }, { label: "License", href: "https://l", external: true }],
      scope: "st-ig", stylesheets: ["assets/ig-pages.css"],
    };
    const script = 'require "liquid"; require "json"; d = JSON.parse(STDIN.read.force_encoding("UTF-8")); print Liquid::Template.parse(d["t"], error_mode: :strict).render("site" => { "data" => { "fhir" => { "footer" => d["f"] } } }, "page" => d["p"])';
    const run = (p: Record<string, string>) => spawnSync("ruby", ["-e", script], { input: JSON.stringify({ t: readFileSync(FOOTER_TEMPLATE_PATH, "utf-8"), f: footer, p }), encoding: "utf-8" });
    const r = run({ ig_prev: "a.html", ig_next: "c.html" });
    expect(r.stderr).toBe("");
    expect(r.stdout).toContain('<link rel="stylesheet" href="assets/ig-pages.css">');
    expect(r.stdout).toContain('<footer id="ig-footer" class="st-ig">');
    expect(r.stdout).toContain('<a href="a.html">&lt;prev</a> | <a href="#">top</a> | <a href="c.html">next&gt;</a>');
    expect(r.stdout).toContain('IG © 2023+ <a href="https://example.org" rel="external">Example Org</a>. Package <code>x.ig#0.2.1</code> based on <a href="http://hl7.org/fhir/R5/" rel="external">FHIR 5.0.0</a>. Generated 2026-10-01');
    expect(r.stdout).toContain('Links: <a href="toc.html">Table of Contents</a> | <a href="https://l" rel="external">License</a>');
    // The first page: no prev, and nothing invented for it.
    expect(run({}).stdout).toContain('<p class="ig-footer-nav"><a href="#">top</a></p>');
  });
});

describe("edit links to the IG's own source (bean `mftp`)", () => {
  test("a pagecontent page carries its edit URL, a generated page none", () => {
    const d = mkdtempSync(join(tmpdir(), "ig-edit-"));
    const src = join(d, "src");
    mkdirSync(join(src, "input", "pagecontent"), { recursive: true });
    writeFileSync(join(src, "sushi-config.yaml"), "id: x.ig\ntitle: X IG\n");
    writeFileSync(join(src, "input", "pagecontent", "concepts.md"), "# C\n");
    stageIgSite(src, join(d, "out"), { menu: { groups: [{ label: "Home", items: [{ label: "C", href: "concepts.html" }] }] }, editBase: "https://github.com/o/r/edit/main" });
    expect(readFileSync(join(d, "out", "concepts.md"), "utf-8")).toContain('ig_edit_url: "https://github.com/o/r/edit/main/input/pagecontent/concepts.md"');
    expect(readFileSync(join(d, "out", "toc.md"), "utf-8")).not.toContain("ig_edit_url");
    expect(readFileSync(join(d, "out", "_layouts", "default.html"), "utf-8")).toContain("Edit this page on GitHub");
    // The standalone layout carries the same opt-in, inside the content it names (bean n7f8).
    expect(readFileSync(join(d, "out", "_layouts", "default.html"), "utf-8")).toMatch(/id="main-content">\n<span hidden data-fa-figure-images="ig"><\/span>/);
    const layout = readFileSync(join(d, "out", "_layouts", "default.html"), "utf-8");
    // Per-section: a source-line link and a pre-filled feedback issue.
    expect(layout).toContain('id="ig-source-lines"');
    // Built in the browser from the platform's one recipe (bean v433).
    expect(layout).toContain("function faBlockUrls");
    expect(layout).toContain('data-fa-link="edit"');
    const fm = readFileSync(join(d, "out", "concepts.md"), "utf-8");
    expect(fm).toContain('ig_source_repo: "o/r"');
    expect(fm).toContain('ig_source_branch: "main"');
    expect(fm).toContain('ig_source_path: "input/pagecontent/concepts.md"');
    expect(readFileSync(join(d, "out", "concepts.md"), "utf-8")).toContain('ig_source_blob: "https://github.com/o/r/blob/main/input/pagecontent/concepts.md"');
    rmSync(d, { recursive: true, force: true });
  });
});

describe("sourceHeadings: each section's line in the IG's source (bean `mftp`)", () => {
  test("ATX headings with their 1-based line, text as a reader sees it, fences skipped", () => {
    const md = ["# Title {#t}", "", "text", "```", "# not a heading", "```", "### A [link](x.html) and **bold**", "## Last ##"].join("\n");
    expect(sourceHeadings(md)).toEqual([
      { t: "Title", l: 1 },
      { t: "A link and bold", l: 7 },
      { t: "Last", l: 8 },
    ]);
  });
});

// Bean `x78e`: an HL7 IG's landing page is `index.md` = `{% include index-ig.md %}`,
// so every heading the reader sees lives in the include. The ✎ / 📣 heading
// links (bean `mftp`) must follow the include to its own file and line.
describe("heading links on an IG's first page, whose headings live in an include (bean `x78e`)", () => {
  /** Run the layout's per-section script against a page holding `headings`, as a browser would. */
  const runHeadingLinks = (js: string, data: unknown, title: string, headings: Array<{ id: string; text: string }>) => {
    const hs = headings.map(({ id, text }) => {
      const links: Array<{ className: string; href: string; textContent: string }> = [];
      return {
        id,
        links,
        textContent: text,
        appendChild(n: { className?: string; href?: string; textContent: string }) {
          if (n.className) links.push(n as { className: string; href: string; textContent: string });
        },
      };
    });
    const document = {
      title,
      getElementById: (id: string) => (id === "ig-source-lines" ? { textContent: JSON.stringify(data) } : null),
      querySelectorAll: () => hs,
      createElement: () => ({ className: "", href: "", title: "", textContent: "", rel: "", target: "" }),
      createTextNode: (t: string) => ({ textContent: t }),
    };
    new Function("document", "location", js)(document, { href: "https://o.github.io/r/#top" });
    return hs.map((h) => ({ id: h.id, edit: h.links.find((a) => a.className === "ig-src")?.href, feedback: h.links.find((a) => a.className === "ig-feedback")?.href }));
  };

  test("index.md that only includes index-ig.md: every heading gets ✎ to its own line in the include and 📣 naming its own section and anchor", () => {
    const d = mkdtempSync(join(tmpdir(), "ig-x78e-"));
    const src = join(d, "src");
    const pc = join(src, "input", "pagecontent");
    mkdirSync(pc, { recursive: true });
    writeFileSync(join(src, "sushi-config.yaml"), "id: x.ig\ntitle: X IG\n");
    writeFileSync(join(pc, "index.md"), "{% include index-ig.md %}\n\n{% include ip-statements.xhtml %}\n");
    writeFileSync(
      join(pc, "index-ig.md"),
      ["An intro paragraph.", "", "<div>", "<p>Under development.</p>", "</div>{:.stu-note}", "", "", "### Summary ", "Summary text.", "", "### About this implementation guide", "", "More.", "", "### Disclaimer", "Text."].join("\n"),
    );
    stageIgSite(src, join(d, "out"), { menu: { groups: [{ label: "Home", items: [{ label: "Summary", href: "index.html" }] }] }, editBase: "https://github.com/o/r/edit/main" });
    const fm = readFileSync(join(d, "out", "index.md"), "utf-8");
    const lines = JSON.parse(/^ig_source_lines: (.*)$/m.exec(fm)?.[1] ?? "null");
    const inc = "https://github.com/o/r/blob/main/input/pagecontent/index-ig.md";
    expect(lines).toEqual([
      { t: "Summary", l: 8, b: inc },
      { t: "About this implementation guide", l: 11, b: inc },
      { t: "Disclaimer", l: 15, b: inc },
    ]);

    // The script the layout carries, on the page as Jekyll renders it. The
    // page is titled after its menu entry — "Summary", the first section's name too.
    const layout = readFileSync(join(d, "out", "_layouts", "default.html"), "utf-8");
    const js = /<script>(\(function\(\)\{var d=document\.getElementById\("ig-source-lines"\)[\s\S]*?)<\/script>/.exec(layout)?.[1];
    expect(js).toBeDefined();
    const got = runHeadingLinks(js!, { blob: "https://github.com/o/r/blob/main/input/pagecontent/index.md", lines }, "Summary | X IG", [
      { id: "summary", text: "Summary" },
      { id: "about-this-implementation-guide", text: "About this implementation guide" },
      { id: "disclaimer", text: "Disclaimer" },
    ]);
    const want = [
      { id: "summary", text: "Summary", l: 8 },
      { id: "about-this-implementation-guide", text: "About this implementation guide", l: 11 },
      { id: "disclaimer", text: "Disclaimer", l: 15 },
    ];
    for (const [i, w] of want.entries()) {
      expect(got[i]!.edit).toBe(`${inc}#L${w.l}`);
      const issue = new URL(got[i]!.feedback!);
      const title = issue.searchParams.get("title")!;
      const body = issue.searchParams.get("body")!;
      // The section first, the page apart from it and only when it is not the
      // section: the defect read "Feedback: Summary — About this implementation guide".
      expect(title).toBe(`Feedback on “${w.text}”${w.text === "Summary" ? "" : " (page: Summary)"}`);
      expect(body).toContain(`**Page:** https://o.github.io/r/#${w.id}\n`);
      expect(body).toContain(`**Section:** ${w.text}`);
      expect(body).toContain(`**Source:** ${inc}#L${w.l}\n`);
    }
    rmSync(d, { recursive: true, force: true });
  });

  test("an include cycle ends, and a non-markdown include is not read", () => {
    const files: Record<string, string> = { "a.md": "# A\n{% include b.md %}", "b.md": "## B\n{% include a.md %}\n{% include x.xhtml %}" };
    const inc = (name: string) => (files[name] ? { md: files[name]!, path: `input/includes/${name}` } : undefined);
    expect(sourceHeadings("{% include a.md %}\n# Own", inc)).toEqual([
      { t: "A", l: 1, p: "input/includes/a.md" },
      { t: "B", l: 1, p: "input/includes/b.md" },
      { t: "Own", l: 2 },
    ]);
  });
});

// Bean `mftp`, owner 2026-10-05: "Build in main site" — the IG's pages wear the
// host site's chrome, with the IG's includes and data namespaced per IG.
describe("composeIgSite: a staged IG moved into a host Jekyll source", () => {
  test("pages nest under the IG, includes and data are namespaced, chrome is injected", () => {
    const d = mkdtempSync(join(tmpdir(), "ig-compose-"));
    const src = join(d, "src");
    mkdirSync(join(src, "input", "pagecontent"), { recursive: true });
    mkdirSync(join(src, "input", "includes"), { recursive: true });
    writeFileSync(join(src, "sushi-config.yaml"), "id: x.ig\ntitle: X IG\n");
    writeFileSync(join(src, "input", "pagecontent", "index.md"), "# Home\n\n{{ site.data.fhir.packageId }}\n");
    writeFileSync(join(src, "input", "pagecontent", "concepts.md"), "# C\n\n{% include note.md %}\n");
    writeFileSync(join(src, "input", "includes", "note.md"), "a note");
    const staged = join(d, "site");
    stageIgSite(src, staged, { menu: { groups: [{ label: "Home", items: [{ label: "Summary", href: "index.html" }] }, { label: "Business", items: [{ label: "Concepts", href: "concepts.html" }] }] }, baseurl: "/b/x" });
    const host = join(d, "host");
    mkdirSync(host, { recursive: true });
    const c = composeIgSite(staged, host, "x");
    expect(c.collisions).toEqual([]);
    const index = readFileSync(join(host, "x", "index.md"), "utf-8");
    expect(index).toMatch(/^---\ntitle: "X IG"\nhas_children: true\n/);
    expect(index).toContain('site.data.ig["x"].fhir.packageId');
    expect(index).toContain("{% include ig/x/_top.html %}");
    expect(index).toContain("{% include ig/_bottom.html %}");
    const concepts = readFileSync(join(host, "x", "concepts.md"), "utf-8");
    expect(concepts).toContain('parent: "Business"');
    expect(concepts).toContain('grand_parent: "X IG"');
    expect(concepts).toContain("layout: default");
    expect(concepts).toContain("{% include ig/x/note.md %}");
    const group = readFileSync(join(host, "x", "menu-business.md"), "utf-8");
    expect(group).toContain('parent: "X IG"');
    expect(existsSync(join(host, "_includes", "ig", "x", "note.md"))).toBe(true);
    expect(existsSync(join(host, "_data", "ig", "x", "fhir.json"))).toBe(true);
    expect(readFileSync(join(host, "_includes", "ig", "x", "_top.html"), "utf-8")).toContain('class="ig-topbar"');
    // Every composed IG page opts its raster images into the shared figure viewer (bean n7f8).
    expect(readFileSync(join(host, "_includes", "ig", "x", "_top.html"), "utf-8")).toContain(IG_FIGURE_IMAGES_STAMP);
    // ...through the attribute the platform's viewer actually reads: the contract is docs-ui.js's.
    expect(IG_FIGURE_IMAGES_STAMP).toContain("data-fa-figure-images");
    const docsUi = readFileSync(join(import.meta.dir, "..", "..", "cat-harness", "docs", "assets", "js", "docs-ui.js"), "utf-8");
    expect(docsUi).toContain('document.querySelector("[data-fa-figure-images]")');
    expect(existsSync(join(host, "x", "_config.yml"))).toBe(false);
    expect(existsSync(join(host, "x", "_layouts"))).toBe(false);
    // A second compose of the same IG is two answers for one URL.
    expect(composeIgSite(staged, host, "x").collisions.length).toBeGreaterThan(0);
    // `atRoot` (#2235 F1): the IG IS the site — the same pages at the root.
    const root = join(d, "root");
    mkdirSync(root, { recursive: true });
    expect(composeIgSite(staged, root, "x", { atRoot: true }).collisions).toEqual([]);
    expect(existsSync(join(root, "index.md"))).toBe(true);
    expect(existsSync(join(root, "concepts.md"))).toBe(true);
    expect(existsSync(join(root, "x"))).toBe(false);
    expect(existsSync(join(root, "_includes", "ig", "x", "_top.html"))).toBe(true);
    rmSync(d, { recursive: true, force: true });
  });
});

describe("relinkPublisherOutputs — the Publisher's downloads live on the published IG", () => {
  test("points a bare .zip/.tgz link at the canonical site", () => {
    const r = relinkPublisherOutputs("* [IG Package](package.tgz)\n* [JSON](definitions.json.zip)", "http://example.org/ig/");
    expect(r.text).toBe("* [IG Package](http://example.org/ig/package.tgz)\n* [JSON](http://example.org/ig/definitions.json.zip)");
    expect(r.count).toBe(2);
  });
  test("leaves pages, paths and absolute URLs alone", () => {
    const t = "[a](index.html) [b](files/x.zip) [c](https://x.org/y.zip) <a href=\"z.tgz\">";
    const r = relinkPublisherOutputs(t, "http://c");
    expect(r.text).toBe("[a](index.html) [b](files/x.zip) [c](https://x.org/y.zip) <a href=\"http://c/z.tgz\">");
    expect(r.count).toBe(1);
  });
});

describe("relinkArtifacts — a case-only mismatch", () => {
  test("resolves to the one artefact page it can mean", () => {
    const r = relinkArtifacts("[model](StructureDefinition-hcert.html)", new Set(["StructureDefinition-HCert"]), "artifact/");
    expect(r.text).toBe("[model](artifact/StructureDefinition-HCert.html)");
  });
  test("is left alone when two pages differ only in case", () => {
    const r = relinkArtifacts("[x](A-b.html)", new Set(["A-B", "a-B"]), "artifact/");
    expect(r.text).toBe("[x](A-b.html)");
    expect(r.count).toBe(0);
  });
});

describe("relinkOffSite — what this build cannot serve goes where it is served", () => {
  const src = mkdtempSync(join(tmpdir(), "offsite-"));
  mkdirSync(join(src, ".github", "skills"), { recursive: true });
  writeFileSync(join(src, ".github", "skills", "s.yaml"), "x");
  mkdirSync(join(src, "input", "bpmn"), { recursive: true });
  writeFileSync(join(src, "input", "bpmn", "D.bpmn"), "x");
  const o = { canonical: "http://example.org/ig", sourceBlob: "https://github.com/o/r/blob/main", srcRoot: src, isServed: (t: string) => t === "index.html" };
  test("a Publisher-only page goes to the published IG", () => {
    expect(relinkOffSite('<a href="qa.html">QA</a>', o).text).toBe('<a href="http://example.org/ig/qa.html">QA</a>');
  });
  test("a repository file goes to GitHub, found at its path or under input/", () => {
    const r = relinkOffSite("[s](.github/skills/s.yaml) [d](bpmn/D.bpmn)", o);
    expect(r.text).toBe("[s](https://github.com/o/r/blob/main/.github/skills/s.yaml) [d](https://github.com/o/r/blob/main/input/bpmn/D.bpmn)");
    expect(r.count).toBe(2);
  });
  test("a page nothing serves is left as written and REPORTED", () => {
    const r = relinkOffSite("[v](video_tutorial.html) [i](index.html)", o);
    expect(r.text).toBe("[v](video_tutorial.html) [i](index.html)");
    expect(r.dead).toEqual(["video_tutorial.html"]);
  });
});

describe("rubyLiquidStrings — a Publisher Liquid string Jekyll can read", () => {
  test("an escaped-quote assign becomes single-quoted with plain quotes", () => {
    const src = '{% assign x__link__html = "<a href=\\"V.html\\">V</a>" %}';
    const r = rubyLiquidStrings(src);
    expect(r.text).toBe(`{% assign x__link__html = '<a href="V.html">V</a>' %}`);
    expect(r.count).toBe(1);
  });
  test("a plain string, and one holding an apostrophe, are left as written", () => {
    const plain = '{% assign a = "plain" %}';
    const apos = '{% assign b = "it\'s <a href=\\"x\\">" %}';
    expect(rubyLiquidStrings(plain + apos).text).toBe(plain + apos);
  });
});

describe("the Publisher's artefact lists, written from the artefact index (bean 9hfi)", () => {
  // A page as an IG's terminology or maps page writes it (bean 9hfi):
  // `list-*.xhtml` fragments the IG Publisher GENERATES, which no
  // IG source holds. Rendered through Liquid as Jekyll renders the page.
  let d: string;
  let o: string;
  let res: StageResult;
  let page: string;
  const list = [
    { resourceType: "CodeSystem", id: "cs-b", title: "beta system", description: "Beta codes" },
    { resourceType: "CodeSystem", id: "cs-a", title: "Alpha system", category: "Terminology: Code Systems" },
    { resourceType: "ValueSet", id: "vs.1", title: "Vaccines", description: "Codes for <vaccines> & boosters" },
    { resourceType: "Library", id: "lib", title: "Logic" },
  ];
  beforeAll(async () => {
    d = mkdtempSync(join(tmpdir(), "ig-lists-"));
    const src = join(d, "src");
    mkdirSync(join(src, "input", "pagecontent"), { recursive: true });
    writeFileSync(join(src, "sushi-config.yaml"), "id: lists.ig\ncanonical: http://example.org/lists\ntitle: Lists IG\nversion: 0.1.0\nfhirVersion: 4.0.1\npages:\n  codings.md:\n    title: Codings\n");
    writeFileSync(
      join(src, "input", "pagecontent", "codings.md"),
      [
        "### CodeSystems",
        "{% include list-simple-codesystems.xhtml %}",
        "",
        "### ValueSets",
        "{% include list-valuesets.xhtml %}",
        "",
        "### Libraries",
        "{% include list-simple-libraries.xhtml %}",
        "",
        "### StructureMaps",
        "<div>",
        "    {% include list-structuremaps.xhtml %}",
        "  </div>",
        "",
        "### Profiles",
        "{% include list-simple-profiles.xhtml %}",
        "",
      ].join("\n"),
    );
    o = join(d, "site");
    res = stageIgSite(src, o, { artifacts: { list, pagesHref: "artifact/" } });
    const { Liquid } = await import("liquidjs");
    const engine = new Liquid({ root: [join(o, "_includes")], jekyllInclude: true, dynamicPartials: false, extname: "" });
    const text = readFileSync(join(o, "codings.md"), "utf-8");
    const body = text.slice(text.indexOf("\n---", 3) + 4);
    page = await engine.parseAndRender(body, { site: { data: { fhir: JSON.parse(readFileSync(join(o, "_data", "fhir.json"), "utf-8")) } } });
  });
  afterAll(() => rmSync(d, { recursive: true, force: true }));

  /** The rendered text between one heading and the next. */
  const section = (h: string) => page.split(`### ${h}`)[1]!.split("### ")[0]!;
  const href = (a: { resourceType: string; id: string }) => `artifact/${artifactPageName(a)}.html`;

  test("a list-simple include on a published IG page lists that type's artefacts, never the placeholder", () => {
    const cs = section("CodeSystems");
    expect(cs).not.toContain("ig-not-rendered");
    expect(cs).not.toContain("not rendered");
    // The Publisher's shape: one <li> per artefact, its title linked to its page, by title.
    expect(cs).toContain(`<ul class="ig-artifact-list">\n <li><a href="${href(list[1]!)}">Alpha system</a></li>\n <li><a href="${href(list[0]!)}">beta system</a></li>\n</ul>`);
    // Simple: no description. Every artefact of the type, categorised or not.
    expect(cs).not.toContain("Beta codes");
    expect(section("Libraries")).toContain(`<a href="${href(list[3]!)}">Logic</a>`);
    expect(res.listed).toEqual(["list-simple-codesystems.xhtml", "list-simple-libraries.xhtml", "list-structuremaps.xhtml", "list-valuesets.xhtml"]);
    expect(res.notRendered).not.toContain("list-simple-codesystems.xhtml");
  });

  test("the full form carries each artefact's description, escaped", () => {
    expect(section("ValueSets")).toContain(`<li><a href="${href(list[2]!)}">Vaccines</a> Codes for &lt;vaccines&gt; &amp; boosters</li>`);
  });

  test("a resource type the index holds none of is SAID, never an empty list or the placeholder", () => {
    const sm = section("StructureMaps");
    expect(sm).toContain("This guide's artefact index holds no StructureMap resources.");
    expect(sm).not.toContain("not rendered");
  });

  test("a list that names no resource type stays a visible marker, and is reported", () => {
    expect(section("Profiles")).toContain("⟦not rendered: list-simple-profiles.xhtml⟧");
    expect(res.notRendered).toEqual(["list-simple-profiles.xhtml"]);
  });

  test("without an artefact index, the lists stay markers rather than empty lists", () => {
    const r2 = stageIgSite(join(d, "src"), join(d, "no-index"));
    expect(r2.listed).toEqual([]);
    expect(r2.notRendered).toContain("list-simple-codesystems.xhtml");
  });

  test("the Publisher's plurals map back to their resource type", () => {
    expect(publisherPlural("CodeSystem")).toBe("codesystems");
    expect(publisherPlural("Library")).toBe("libraries");
    expect(publisherPlural("SubscriptionStatus")).toBe("subscriptionstatuses");
    expect(publisherPlural("RelatedPerson")).toBe("relatedpeople");
    expect(artifactListInclude("list-simple-valuesets.xhtml")).toEqual({ resourceType: "ValueSet", simple: true });
    expect(artifactListInclude("list-structuremaps.xhtml")).toEqual({ resourceType: "StructureMap", simple: false });
    expect(artifactListInclude("list-simple-profiles.xhtml")).toBeUndefined();
    expect(artifactListInclude("list-simple-valuesets-json.xhtml")).toBeUndefined();
  });

  test("the list template is a file that opens with its description and computes nothing", () => {
    const t = readFileSync(ARTIFACT_LIST_TEMPLATE_PATH, "utf-8");
    expect(t.startsWith("{%- comment -%}")).toBe(true);
    expect(t).not.toMatch(/\|\s*(plus|minus|size|replace|sort)\b/);
  });
});
