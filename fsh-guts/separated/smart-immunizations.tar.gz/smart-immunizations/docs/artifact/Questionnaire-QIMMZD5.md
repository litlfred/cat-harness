---
title: "IMMZ.D5.Determine vaccine(s) to be administered based on contraindications — WHO SMART Immunizations artefact"
description: "Questionnaire/QIMMZD5 in the WHO SMART Immunizations IG, with its canonical URL, published representations and DAK API sidecars."
nav_exclude: true
ig_footer: true
ig_root: "../"
ig_prev: "Questionnaire-QIMMZD21.html"
ig_next: "Questionnaire-QIMMZD7.html"
---
<link rel="stylesheet" href="../assets/ig-pages.css">
<link rel="stylesheet" href="../assets/ig-chrome.css">

<div class="st-ig">
  <div class="st-ig-bar"><a href="http://smart.who.int/immunizations">smart.who.int.immunizations</a></div>
  <div id="ig-status">
    <p><span class="st-ig-title">WHO SMART Immunizations</span><br/><span>0.2.0</span></p>
  </div>
  <p id="publish-box">This page mirrors a published WHO Implementation Guide. The authoritative version is at <a href="http://smart.who.int/immunizations">http://smart.who.int/immunizations</a>.</p>
</div>

[← all 748 artefacts](../artifacts.html)

## IMMZ.D5.Determine vaccine(s) to be administered based on contraindications

`Questionnaire/QIMMZD5`

Questionnaire for IMMZ.D5.Determine vaccine(s) to be administered based on contraindications

<div class="st-grid"><div class="st-stat"><b>Questionnaire</b><span>resource type</span></div><div class="st-stat"><b>0.2.0</b><span>version</span></div><div class="st-stat"><b>Structures: Questionnaires</b><span>category</span></div></div>

## Identity and bytes are different questions

| | |
|---|---|
| Canonical URL | `http://smart.who.int/immunizations/Questionnaire/QIMMZD5` |
| Published | <a href="https://worldhealthorganization.github.io/smart-immunizations/Questionnaire-QIMMZD5.json">json</a> · <a href="https://worldhealthorganization.github.io/smart-immunizations/Questionnaire-QIMMZD5.xml">xml</a> · <a href="https://worldhealthorganization.github.io/smart-immunizations/Questionnaire-QIMMZD5.ttl">ttl</a> · <a href="https://worldhealthorganization.github.io/smart-immunizations/Questionnaire-QIMMZD5.html">html</a> |
| Materialization | <span class="st-tag st-ref">referenced</span> — upstream, not held here |

## DAK API

No DAK API sidecar is published for this artefact. That is a fact about the IG,
not a gap in this index — sidecars are published per artefact, and
200 of 748 carry one.
