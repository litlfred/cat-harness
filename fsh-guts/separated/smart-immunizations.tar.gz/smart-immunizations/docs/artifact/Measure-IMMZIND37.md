---
title: "IMMZIND37 — WHO SMART Immunizations artefact"
description: "Measure/IMMZIND37 in the WHO SMART Immunizations IG, with its canonical URL, published representations and DAK API sidecars."
nav_exclude: true
ig_footer: true
ig_root: "../"
ig_prev: "Measure-IMMZIND36.html"
ig_next: "Measure-IMMZIND38.html"
---
<link rel="stylesheet" href="../assets/ig-pages.css">
<link rel="stylesheet" href="../assets/ig-chrome.css">

<div class="st-ig">
  <div class="st-ig-bar"><a href="http://smart.who.int/immunizations">smart.who.int.immunizations</a></div>
  <div id="ig-status">
    <p><span class="st-ig-title">WHO SMART Immunizations</span><br/><span>0.2.0</span></p>
  </div>
  <p id="publish-box">This page mirrors a published WHO Implementation Guide. The authoritative version is at <a href="http://smart.who.int/immunizations">http://smart.who.int/immunizations</a>.</p>
</div>

[← all 748 artefacts](../artifacts.html)

## IMMZIND37

`Measure/IMMZIND37`

IMMZ.IND.37 Drop-out rate from the 1st dose of measles and rubella-containing vaccine to the 2nd dose

<div class="st-grid"><div class="st-stat"><b>Measure</b><span>resource type</span></div><div class="st-stat"><b>0.2.0</b><span>version</span></div><div class="st-stat"><b>Knowledge Artifacts: Measure</b><span>category</span></div></div>

## Identity and bytes are different questions

| | |
|---|---|
| Canonical URL | `http://smart.who.int/immunizations/Measure/IMMZIND37` |
| Published | <a href="https://worldhealthorganization.github.io/smart-immunizations/Measure-IMMZIND37.json">json</a> · <a href="https://worldhealthorganization.github.io/smart-immunizations/Measure-IMMZIND37.xml">xml</a> · <a href="https://worldhealthorganization.github.io/smart-immunizations/Measure-IMMZIND37.ttl">ttl</a> · <a href="https://worldhealthorganization.github.io/smart-immunizations/Measure-IMMZIND37.html">html</a> |
| Materialization | <span class="st-tag st-ref">referenced</span> — upstream, not held here |

## DAK API

No DAK API sidecar is published for this artefact. That is a fact about the IG,
not a gap in this index — sidecars are published per artefact, and
200 of 748 carry one.
