---
title: "Example QuestionnaireReponse for Capture Client History for Hepatitis A — WHO SMART Immunizations artefact"
description: "QuestionnaireResponse/Example.IMMZ.D1.QuestionnaireResponse.HepA in the WHO SMART Immunizations IG, with its canonical URL, published representations and DAK API sidecars."
nav_exclude: true
ig_footer: true
ig_root: "../"
ig_prev: "QuestionnaireResponse-Example.IMMZ.D1.QuestionnaireResponse.Flu.html"
ig_next: "QuestionnaireResponse-Example.IMMZ.D1.QuestionnaireResponse.HepB.html"
---
<link rel="stylesheet" href="../assets/ig-pages.css">
<link rel="stylesheet" href="../assets/ig-chrome.css">

<div class="st-ig">
  <div class="st-ig-bar"><a href="http://smart.who.int/immunizations">smart.who.int.immunizations</a></div>
  <div id="ig-status">
    <p><span class="st-ig-title">WHO SMART Immunizations</span><br/><span>0.2.0</span></p>
  </div>
  <p id="publish-box">This page mirrors a published WHO Implementation Guide. The authoritative version is at <a href="http://smart.who.int/immunizations">http://smart.who.int/immunizations</a>.</p>
</div>

[← all 748 artefacts](../artifacts.html)

## Example QuestionnaireReponse for Capture Client History for Hepatitis A

`QuestionnaireResponse/Example.IMMZ.D1.QuestionnaireResponse.HepA`

Example QuestionnaireReponse for IMMZ.D1.Capture or update client history. For patient receiving Hepatitis A vaccine.

<div class="st-grid"><div class="st-stat"><b>QuestionnaireResponse</b><span>resource type</span></div><div class="st-stat"><b>—</b><span>version</span></div><div class="st-stat"><b>Example: Example Instances</b><span>category</span></div></div>

## Identity and bytes are different questions

| | |
|---|---|
| Canonical URL | *none — examples and instances have no canonical URL* |
| Published | <a href="https://worldhealthorganization.github.io/smart-immunizations/QuestionnaireResponse-Example.IMMZ.D1.QuestionnaireResponse.HepA.json">json</a> · <a href="https://worldhealthorganization.github.io/smart-immunizations/QuestionnaireResponse-Example.IMMZ.D1.QuestionnaireResponse.HepA.xml">xml</a> · <a href="https://worldhealthorganization.github.io/smart-immunizations/QuestionnaireResponse-Example.IMMZ.D1.QuestionnaireResponse.HepA.ttl">ttl</a> · <a href="https://worldhealthorganization.github.io/smart-immunizations/QuestionnaireResponse-Example.IMMZ.D1.QuestionnaireResponse.HepA.html">html</a> |
| Materialization | <span class="st-tag st-ref">referenced</span> — upstream, not held here |

## DAK API

No DAK API sidecar is published for this artefact. That is a fact about the IG,
not a gap in this index — sidecars are published per artefact, and
200 of 748 carry one.
