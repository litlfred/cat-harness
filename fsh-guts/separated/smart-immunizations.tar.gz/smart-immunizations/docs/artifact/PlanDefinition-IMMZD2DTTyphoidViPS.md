---
title: "IMMZ.D2.DT.Typhoid.ViPS — WHO SMART Immunizations artefact"
description: "PlanDefinition/IMMZD2DTTyphoidViPS in the WHO SMART Immunizations IG, with its canonical URL, published representations and DAK API sidecars."
nav_exclude: true
ig_footer: true
ig_root: "../"
ig_prev: "PlanDefinition-IMMZD2DTTyphoidTy21a.html"
ig_next: "PlanDefinition-IMMZD2DTVaricella1Dose.html"
---
<link rel="stylesheet" href="../assets/ig-pages.css">
<link rel="stylesheet" href="../assets/ig-chrome.css">

<div class="st-ig">
  <div class="st-ig-bar"><a href="http://smart.who.int/immunizations">smart.who.int.immunizations</a></div>
  <div id="ig-status">
    <p><span class="st-ig-title">WHO SMART Immunizations</span><br/><span>0.2.0</span></p>
  </div>
  <p id="publish-box">This page mirrors a published WHO Implementation Guide. The authoritative version is at <a href="http://smart.who.int/immunizations">http://smart.who.int/immunizations</a>.</p>
</div>

[← all 748 artefacts](../artifacts.html)

## IMMZ.D2.DT.Typhoid.ViPS

`PlanDefinition/IMMZD2DTTyphoidViPS`

IMMZ.D2.DT.Typhoid.ViPS Unconjugated Vi polysaccharide (ViPS) schedule

<div class="st-grid"><div class="st-stat"><b>PlanDefinition</b><span>resource type</span></div><div class="st-stat"><b>0.2.0</b><span>version</span></div><div class="st-stat"><b>Knowledge Artifacts: Plan Definitions</b><span>category</span></div></div>

## Identity and bytes are different questions

| | |
|---|---|
| Canonical URL | `http://smart.who.int/immunizations/PlanDefinition/IMMZD2DTTyphoidViPS` |
| Published | <a href="https://worldhealthorganization.github.io/smart-immunizations/PlanDefinition-IMMZD2DTTyphoidViPS.json">json</a> · <a href="https://worldhealthorganization.github.io/smart-immunizations/PlanDefinition-IMMZD2DTTyphoidViPS.xml">xml</a> · <a href="https://worldhealthorganization.github.io/smart-immunizations/PlanDefinition-IMMZD2DTTyphoidViPS.ttl">ttl</a> · <a href="https://worldhealthorganization.github.io/smart-immunizations/PlanDefinition-IMMZD2DTTyphoidViPS.html">html</a> |
| Materialization | <span class="st-tag st-ref">referenced</span> — upstream, not held here |

## DAK API

No DAK API sidecar is published for this artefact. That is a fact about the IG,
not a gap in this index — sidecars are published per artefact, and
200 of 748 carry one.
